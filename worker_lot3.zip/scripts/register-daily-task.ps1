param([string]$TaskName = "CompanySearchWorker")
$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$pythonPath = Join-Path $projectRoot ".venv\Scripts\python.exe"
$envPath = Join-Path $projectRoot ".env"
if (!(Test-Path -LiteralPath $pythonPath)) { throw "Create the project virtual environment first." }
if (!(Test-Path -LiteralPath $envPath)) { throw "Create .env first." }
$scheduleLine = Get-Content -LiteralPath $envPath | Where-Object { $_ -match '^\s*SCHEDULE_TIME\s*=' } | Select-Object -Last 1
if (!$scheduleLine) { throw "Set SCHEDULE_TIME=HH:mm in .env." }
$timeValue = ($scheduleLine -split '=', 2)[1].Trim().Trim('"').Trim("'")
$runTime = [datetime]::ParseExact($timeValue, 'HH:mm', [cultureinfo]::InvariantCulture)
$action = New-ScheduledTaskAction -Execute $pythonPath -Argument '-m lot_worker.cli run' -WorkingDirectory $projectRoot
$trigger = New-ScheduledTaskTrigger -Daily -At $runTime
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 12)
$principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description "Company matching worker; SQL Server enforces the daily quota."
Write-Output "Registered $TaskName at $timeValue Windows local time. This task runs while this user is logged in."
