# Company packet matching worker

Two separate operations, both persisted in SQL Server:

```mermaid
flowchart LR
    S[Source table: configured 32 columns] --> P[Layer 1: assign accounts to packets]
    P --> Q[Saved packet membership and source snapshots]
    Q --> M[Layer 2: apply each packet's location rules]
    A[Read-only account masterfile] --> M
    M --> J[JSON: account IDs, confidence, evidence, all source columns]
```

Layer 1 uses company-name patterns only. Layer 2 starts after the entire packetization batch is ready. Accounts may belong to **every matching packet**, as configured by `overlap_policy: "all"`. Each membership has an independent matching status and may produce different results.

## Files to edit

| File | Purpose |
| --- | --- |
| [config/source_columns.json](config/source_columns.json) | Editable list of 32 dummy source columns; replace with your production names |
| [config/packets.json](config/packets.json) | 14 dummy packets, aliases, exclusions, and independent location rules |
| [.env.example](.env.example) | Database connections, table names, role mappings, limits, paths, schedule |
| [examples/packet_matching_sample.json](examples/packet_matching_sample.json) | Generated result of both layers using fictional data |

The packet definitions are Amazon plus 13 fictional examples: Cedar, Harbor, Maple, Summit, Willow, Quartz, Silver, Copper, Meadow, Pine, Birch, Aspen, and Oak. Rename/add/remove entries and replace their patterns and rules. These are editable examples, not inferred production definitions.

`backend/lot_worker/` contains separate routing, packetization, location-comparison, worker, progress, and export modules. Tests are in `backend/tests/`; the Windows scheduler script is in `scripts/`. No frontend or HTTP server is required.

## Setup

Install SQL Server 2016+ and Microsoft ODBC Driver 18 for SQL Server. From the repository root:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e './backend[test]'
Copy-Item .env.example .env
```

Edit `.env` before connecting. Sample values (full template in `.env.example`):

```dotenv
DATABASE_URL=mssql+pyodbc://worker:CHANGE_ME@localhost/company_worker?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes&TrustServerCertificate=no
SOURCE_DATABASE_URL=mssql+pyodbc://reader:CHANGE_ME@localhost/company_worker?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes&TrustServerCertificate=no
SOURCE_SCHEMA=dbo
SOURCE_TABLE=lot_demo_companies
SOURCE_COLUMNS_PATH=./config/source_columns.json
SOURCE_ID_COLUMN=CompanyID
SOURCE_NAME_COLUMN=CompanyName
SOURCE_ADDRESS_COLUMN=Address
SOURCE_CITY_COLUMN=City
SOURCE_STATE_COLUMN=State
SOURCE_PROVINCE_COLUMN=Province
PACKET_CONFIG_PATH=./config/packets.json
MASTER_SCHEMA=dbo
MASTER_TABLE=lot_demo_accounts
MASTER_ACCOUNT_ID_COLUMN=AccountID
MASTER_ADDRESS_COLUMN=Address
MASTER_CITY_COLUMN=City
MASTER_STATE_COLUMN=State
MASTER_PROVINCE_COLUMN=Province
SOURCE_MAX_ROWS=250000
MASTER_MAX_ROWS=250000
DAILY_LIMIT=100
TIMEZONE=Asia/Manila
OUTPUT_ROOT=./output
SCHEDULE_TIME=09:00
```

`DATABASE_URL` is the writable application database. Its user needs default schema `dbo`, table creation permissions for initialization, and read/write permissions on worker tables. `SOURCE_DATABASE_URL` must be SELECT-only. The masterfile uses the source connection unless `MASTER_DATABASE_URL` is configured with a different SELECT-only SQL Server URL. Source and masterfile access accepts constructed SELECT queries only; no user-provided SQL is executed. URL-encode password punctuation and keep `.env` out of source control.

The database must already exist. `init-db` creates missing worker tables, including `lot_packet_batches`, `lot_packet_accounts`, and `lot_packet_tasks`; it does not alter existing table columns or migrate databases.

## Layer 1: packetization

The source column JSON list is a literal list, without SQL brackets, aliases, or expressions. All six role mappings from `.env` must appear in it. The number of columns can change; 32 is the initial dummy list. Changing this list changes the selected/exported columns, not the production database schema. `SOURCE_ID_COLUMN` must uniquely identify a source row. For repeated account IDs in your source, expose a unique row identifier in a view.

All selected values are saved under `source_data` using their original column names. Nulls remain null. Dates/times become ISO strings; decimals become strings to preserve precision; binary values are tagged base64 objects. Source fields and packet memberships remain available even for invalid addresses. Address eligibility is evaluated in layer 2.

Amazon starts with these patterns:

```json
"include": [
  {"mode": "contains", "value": "Amazon"},
  {"mode": "contains", "value": "AMZN"}
]
```

These capture `123Amazon`, `AWSAmzn`, `ORD01AMZN`, and `TX-001Amzn`. Supported modes are literal, case-insensitive `contains`, `exact`, and `starts_with`. Unicode and whitespace are normalized; patterns are not SQL LIKE expressions or regular expressions. Optional `exclude` patterns take precedence for that packet.

Each matching packet gets one task for the source account, regardless of how many aliases matched. Overlapping membership is retained in all packets. Accounts with no matching packet are saved as `unassigned` and appear in the export. The implementation also supports `review` or `priority` overlap policies if you later change the configuration; priority chooses the lowest priority number, with packet ID breaking ties.

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli init-db
.\.venv\Scripts\python.exe -m lot_worker.cli packetize
```

This prints a batch ID and a packet snapshot JSON path. It does **not** match against the masterfile. The source is scanned once and progress is committed/logged every 500 rows. Duplicate source IDs, missing columns, or exceeding `SOURCE_MAX_ROWS` fail the batch. Failed/interrupted partial batches cannot enter layer 2.

Each explicit `packetize` invocation creates a **new snapshot and new tasks**, including accounts previously processed in another batch. Do not schedule repeated packetization unless reprocessing new snapshots is intended. Editing packet configuration affects future snapshots only; saved tasks use the exact rules captured when they were packetized. For a stable read while production data changes, use a suitable database snapshot/isolation strategy or a staging view/table managed by your database administrator.

## Layer 2: packet-specific matching

Every packet contains its own `matching` block. The Amazon example is:

```json
"matching": {
  "fields": {
    "address": {"mode": "similarity", "required": true, "weight": 70},
    "city": {"mode": "exact", "required": true, "weight": 10},
    "state": {"mode": "exact", "required": false, "weight": 10},
    "province": {"mode": "exact", "required": false, "weight": 10}
  },
  "address_similarity_min": 0.90,
  "minimum_score": 80
}
```

Rules must include all four fields, and weights must total 100. A field can use normalized `exact` or `ignore`; address additionally supports `similarity`. An ignored field must have `weight: 0` and `required: false`. At least one exact field must be required to bound masterfile candidates. The dummy packets demonstrate different profiles, including exact addresses and province-based comparison with city ignored.

- A required field must exist on both records. Optional missing fields earn no points. Conflicting known values on an active exact field reject the match. Only explicitly ignored fields may conflict without rejection.
- Blank/PO Box source addresses are excluded in layer 2 regardless of packet rules. Master rows with blank/PO Box addresses are excluded when loaded. Missing masterfile cities can be used by packets whose rules require a different field.
- Address normalization recognizes common street/unit abbreviations. Approximate address matching requires the configured similarity threshold and rejects different numeric or explicit unit identifiers. It does not geocode, infer state codes, or establish corporate ownership.
- Score is the rounded sum of each field's weight times its similarity (exact agreement is 1; missing is 0). A score is high only when it is 100 and all four fields agree. Ignored fields or non-exact addresses cap the score at 94. Medium is 85 or more; remaining accepted scores are low. Scores are rule-based evidence, not calibrated probabilities.
- All qualifying masterfile account IDs are retained. Duplicate rows for one ID contribute distinct evidence without duplicate IDs. Multiple IDs or non-high confidence require review. Leading zeros are preserved when the masterfile stores IDs as text.

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli run
# Optional: process only a specific saved batch
.\.venv\Scripts\python.exe -m lot_worker.cli run --batch-id YOUR_BATCH_ID
```

The worker reads saved source snapshots, not the live source rows. The masterfile is loaded once per run using the current masterfile connection/mappings. An account in two packets uses two independent matching attempts. `DAILY_LIMIT=100` means **100 account/packet attempts per local calendar day**, shared across batches and legacy runs. Failures and excluded addresses count. Completed tasks are not repeated on a later `run`. The masterfile read cap fails before charging new attempts, rather than silently truncating results.

SQL Server application locking serializes packetization and matching. Interrupted tasks are marked on the next run and remain charged; failed/interrupted tasks require manual review, with no automatic retry/reset. Source and masterfile rows are never modified by these operations.

## Progress and JSON

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli status
.\.venv\Scripts\python.exe -m lot_worker.cli status --batch-id YOUR_BATCH_ID
.\.venv\Scripts\python.exe -m lot_worker.cli export --batch-id YOUR_BATCH_ID --output packet-results.json
```

Status shows the source row count, assigned/unassigned/ambiguous counts, totals and statuses per packet, completion percentage, and today's used/remaining allowance. Completion includes unsuccessful and excluded tasks; it does not imply a successful match. Empty packets display 0%. During packetization, counts reflect committed rows. There is no ETA. Runtime logs report batch and packet progress without credentials or driver exception text.

Packetization automatically exports the full saved snapshot. Each matching run exports its attempted tasks, grouped by batch and packet, including original source columns, assignment evidence, matching rules, account IDs, confidence, and field evidence. Empty packet groups remain visible. Files use unique names under `OUTPUT_ROOT`. Use `export` for the entire current snapshot, including pending and unassigned accounts; omit `--batch-id` to export all batches. Existing output files are never overwritten. If writing JSON fails, persisted work remains available for a later export.

## Dummy data and upgrade

The dummy source has 23 rows and 32 columns, the masterfile has 13 rows, and the packet configuration has 14 packets. All company details, locations, and account IDs are fictional. The shared `Amazon Cedar Shared Account` belongs to both packets. A full dummy run produces 23 account/packet tasks from 22 assigned source rows; one source row is unassigned. Blank/PO Box accounts remain visible in their packets and finish as `excluded_address`.

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli seed-demo
.\.venv\Scripts\python.exe -m lot_worker.cli packetize
.\.venv\Scripts\python.exe -m lot_worker.cli run
.\.venv\Scripts\python.exe -m lot_worker.cli status
```

Use a **fresh demo database** for the expanded 32-column schema. `seed-demo` creates and seeds only the application database's dedicated demo tables; it does not alter old demo tables or seed configured external production tables. Grant the source reader SELECT on both demo tables after seeding. Re-seeding unchanged dummy records is idempotent. Existing production source/master tables are not migrated by this worker.

The previous Excel/CSV name-search workflow remains available as `ingest`, `run-legacy`, and `export-legacy`. `seed-demo` also keeps its legacy search list for compatibility, but `run` now processes packet tasks only. Legacy `.env` values such as `MATCH_MODE`, `MAX_RESULTS`, `ADDRESS_SIMILARITY_MIN`, and `ACCOUNT_SCORE_MIN` do not override packet rules. Prior legacy data is retained and shown separately in status; it is not automatically converted into packets.

## Scheduling and verification

If a command reports `ProgrammingError`, run this read-only diagnostic first:

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli check-db
```

It checks every application table, the configured source columns, and the configured masterfile columns with zero-row SELECT queries. It makes no schema or data changes and does not test write permissions or application locks. Failures include the operation stage, SQLSTATE, a recognized native error code, and a suggested action. Invalid-column diagnostics additionally probe each configured column and list those that fail. Raw SQL, driver error text, credentials, and connection strings are not printed.

SQL Server [error 207](https://learn.microsoft.com/en-us/sql/relational-databases/errors-events/mssqlserver-207-database-engine-error) indicates an invalid column; check the 32-column list and role mappings against the actual table. [Error 208](https://learn.microsoft.com/en-us/sql/relational-databases/errors-events/mssqlserver-208-database-engine-error) indicates an unresolved object; check the database/schema/table and access. For missing application tables run `init-db` against the intended application database. This does not add missing columns to an old demo table. If `check-db` succeeds but another command fails, share the command and its new safe diagnostic output; SELECT checks alone do not establish that writes or locks work.

Backend run command: `python -m lot_worker.cli run` in the installed virtual environment. Frontend run command: not applicable; this is a CLI worker.

```powershell
.\scripts\register-daily-task.ps1
Get-ScheduledTask -TaskName CompanySearchWorker
.\.venv\Scripts\python.exe -m pytest backend/tests -q
```

The task runs layer 2 against existing ready packets; run `packetize` explicitly when you intend to create a new source snapshot. The script reads `SCHEDULE_TIME` and uses the project's virtual environment and working directory. Windows local timezone should agree with `TIMEZONE`. It runs while the current user is logged in; configure an appropriate Task Scheduler account for unattended execution while logged out. It does not overwrite an existing scheduled task or persist console logs to a file.

Tests exercise all four Amazon aliases, all 32 preserved columns, overlapping memberships, independent packet rules, saved snapshots, partial-batch rejection, daily limits, confidence, exports, and progress. Tests use SQLite and fake SQL Server locks; live SQL Server connectivity, locking, source types, and scheduled execution remain unverified. Before scheduling production runs, packetize a small test view, inspect membership JSON, set `DAILY_LIMIT=2`, run twice to verify the quota, compare results to known master records, then restore 100.

No Google Search API or Hoovers/D&B integration is included. The dummy packet names, column list, and connection values are placeholders for your production configuration.
