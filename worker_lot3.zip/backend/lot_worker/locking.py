from contextlib import contextmanager

from sqlalchemy import text


LOCK_NAME = "company-lot-worker"
ACQUIRE = text("""
SET NOCOUNT ON;
DECLARE @result int;
EXEC @result = sys.sp_getapplock @Resource=:resource,
    @LockMode='Exclusive', @LockOwner='Session', @LockTimeout=0;
SELECT @result;
""")
RELEASE = text("""
SET NOCOUNT ON;
DECLARE @result int;
EXEC @result = sys.sp_releaseapplock @Resource=:resource, @LockOwner='Session';
SELECT @result;
""")


@contextmanager
def exclusive_connection(engine):
    """Serialize application writes; never execute these procedures on the source."""
    with engine.connect() as connection:
        code = connection.scalar(ACQUIRE, {"resource": LOCK_NAME})
        connection.commit()
        if code == -1:
            yield None
            return
        if code not in (0, 1):
            connection.invalidate()
            raise RuntimeError("SQL Server application lock failed")
        try:
            # All writes use this connection so losing the lock session stops the run.
            yield connection
        finally:
            try:
                connection.rollback()
                result = connection.scalar(RELEASE, {"resource": LOCK_NAME})
                connection.commit()
                if result != 0:
                    raise RuntimeError("SQL Server application lock release failed")
            except BaseException:
                # Never return a session that may still own a lock to the pool.
                connection.invalidate()
                raise
