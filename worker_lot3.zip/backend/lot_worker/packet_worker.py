import logging
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .locking import exclusive_connection
from .masterfile import load_master_index
from .matching import valid_address
from .models import PacketAccount, PacketBatch, PacketTask
from .packet_config import PacketConfiguration
from .packet_export import automatic_packet_export
from .packet_progress import daily_used
from .errors import error_details

logger = logging.getLogger(__name__)


def pending_query(batch_id=None):
    query = select(PacketTask, PacketAccount, PacketBatch).join(
        PacketAccount, PacketTask.account_id == PacketAccount.id).join(
        PacketBatch, PacketAccount.batch_id == PacketBatch.id).where(
        PacketBatch.status == "ready", PacketTask.status == "pending").order_by(PacketTask.id)
    return query.where(PacketBatch.id == batch_id) if batch_id else query


def claim_packet_task(connection, settings, batch_id=None):
    day = datetime.now(ZoneInfo(settings.timezone)).date()
    with Session(connection) as session, session.begin():
        if daily_used(session, day) >= settings.daily_limit:
            return None
        row = session.execute(pending_query(batch_id).limit(1)).first()
        if row is None:
            return None
        task, account, batch = row
        configuration = PacketConfiguration.model_validate(batch.configuration)
        packet = next(packet for packet in configuration.packets if packet.id == task.packet_id)
        task.status, task.run_date, task.started_at = "running", day, datetime.now(timezone.utc)
        return task.id, account.source_record, packet


def finish_packet_task(connection, task_id, status, result=None, error_code=None):
    with Session(connection) as session, session.begin():
        session.execute(update(PacketTask).where(PacketTask.id == task_id).values(
            status=status, result=result, error_code=error_code, finished_at=datetime.now(timezone.utc)))


def match_one(connection, master, settings, claimed):
    task_id, record, packet = claimed
    if not valid_address(record.get("address")):
        finish_packet_task(connection, task_id, "excluded_address", {
            "account_ids": [], "account_matches": [], "no_match_reason": "blank_or_po_box_address",
            "review_required": True})
        logger.info("packet_match_complete task_id=%s packet=%s status=excluded_address", task_id, packet.id)
        return
    source = {key: value for key, value in record.items() if key != "source_data"}
    result = master.match(source, settings, rules=packet.matching)
    result["packet_id"] = packet.id
    result["master_source"] = {"schema": settings.master_schema, "table": settings.master_table,
                               "account_id_column": settings.master_account_id_column}
    status = "matched" if result["account_ids"] else "no_account_match"
    finish_packet_task(connection, task_id, status, result)
    logger.info("packet_match_complete task_id=%s packet=%s status=%s account_matches=%s",
                task_id, packet.id, status, len(result["account_ids"]))


def process_packets(engine, source, settings, master_source=None, batch_id=None):
    attempts, failed = [], 0
    errors = []
    with exclusive_connection(engine) as lock:
        if lock is None:
            return {"status": "busy", "message": "Another worker is running", "data": {}}
        with Session(lock) as session, session.begin():
            if batch_id:
                batch = session.get(PacketBatch, batch_id)
                if batch is None or batch.status != "ready":
                    raise ValueError("Requested packet batch does not exist or is not ready")
            session.execute(update(PacketTask).where(PacketTask.status == "running").values(
                status="interrupted", error_code="PROCESS_INTERRUPTED", finished_at=datetime.now(timezone.utc)))
            available = session.execute(pending_query(batch_id).limit(1)).first() is not None
            remaining = settings.daily_limit - daily_used(session, datetime.now(ZoneInfo(settings.timezone)).date())
        if available and remaining > 0:
            master = load_master_index(master_source if master_source is not None else source, settings)
            while claimed := claim_packet_task(lock, settings, batch_id):
                attempts.append(claimed[0])
                try:
                    match_one(lock, master, settings, claimed)
                except Exception as exc:
                    errors.append(error_details(exc, "packet_matching_or_save"))
                    finish_packet_task(lock, claimed[0], "failed", error_code=type(exc).__name__)
                    logger.error("packet_match_failed task_id=%s error_type=%s", claimed[0], type(exc).__name__)
                    failed += 1
                    break
    output = automatic_packet_export(engine, settings.output_root, batch_id, attempts)
    return {"status": "error" if failed else "success", "message": "Packet matching run finished",
            "data": {"attempted": len(attempts), "failed": failed, "output_file": output,
                     **({"errors": errors} if errors else {})}}
