"""Translate known driver codes without exposing raw SQL, parameters, or credentials."""
import re


DIAGNOSTICS = {
    207: ("invalid_column", "A configured database column does not exist.",
          "Run check-db. Compare SOURCE_COLUMNS_PATH and SOURCE_* / MASTER_* mappings with the actual tables. Older demo tables do not gain new columns through init-db."),
    208: ("missing_table", "A required table or view could not be resolved.",
          "Run check-db. For application tables, run init-db against the intended database. For source/master tables, verify the database, schema, table name, and reader access."),
    229: ("permission_denied", "The database user lacks permission for this operation.",
          "Check application-table permissions and SELECT permissions on the configured source/master views."),
    262: ("create_permission_denied", "The application user cannot create a required database object.",
          "Have the database administrator initialize the application tables or grant the required application database permissions."),
    102: ("sql_syntax", "SQL Server rejected the statement syntax.",
          "Run check-db and report the failing command and stage, SQLSTATE, and native code."),
    156: ("sql_syntax", "SQL Server rejected the statement syntax.",
          "Run check-db and report the failing command and stage, SQLSTATE, and native code."),
    18456: ("login_failed", "SQL Server rejected the login.",
            "Check the configured authentication method and credentials without sharing connection strings."),
    4060: ("database_unavailable", "The configured database cannot be opened by this login.",
           "Check that the database exists and that the configured login has access."),
}


def error_details(exc: Exception, stage: str) -> dict:
    original = getattr(exc, "orig", exc)
    arguments = getattr(original, "args", ())
    state = arguments[0] if arguments and isinstance(arguments[0], str) and re.fullmatch(r"[A-Z0-9]{5}", arguments[0]) else None
    # Inspect messages only for known numeric codes; never return the message itself.
    codes = [int(code) for argument in arguments if isinstance(argument, str)
             for code in re.findall(r"\((-?\d+)\)", argument)]
    native = next((code for code in codes if code in DIAGNOSTICS), None)
    fallback = {"42S22": 207, "42S02": 208}
    diagnosis = DIAGNOSTICS.get(native or fallback.get(state))
    if diagnosis is None:
        diagnosis = ("unclassified_error", "The command failed; the available error code does not identify the cause.",
                     "Run check-db and share its safe JSON output together with the failing command.")
    category, explanation, action = diagnosis
    return {"error_type": type(exc).__name__, "stage": stage, "sqlstate": state,
            "native_code": native, "category": category, "explanation": explanation, "action": action}
