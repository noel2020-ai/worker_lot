import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Attempt, Job


def export_results(engine, path: Path, attempt_ids: list[int] | None = None) -> int:
    statement = select(Job, Attempt).join(Attempt, Attempt.job_id == Job.id).order_by(Attempt.id)
    if attempt_ids is not None:
        statement = statement.where(Attempt.id.in_(attempt_ids))
    with Session(engine) as session:
        records = []
        for job, attempt in session.execute(statement):
            account_ids = sorted({account_id for match in attempt.results for account_id in match.get("account_ids", [])})
            records.append({"job_id": job.id, "input_name": job.name, "status": attempt.status,
                            "run_date": str(attempt.run_date), "match_mode": attempt.match_mode,
                            "account_ids": account_ids, "matches": attempt.results,
                            "truncated": attempt.truncated, "error_code": attempt.error_code})
    # Exclusive creation protects previous exports. The persisted attempts can be exported again on failure.
    with path.open("x", encoding="utf-8") as output:
        json.dump(records, output, indent=2, ensure_ascii=False, allow_nan=False)
    return len(records)


def export_run(engine, output_root: Path, attempt_ids: list[int]) -> str:
    output_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = output_root / f"matches-{timestamp}-{uuid4().hex}.json"
    export_results(engine, path, attempt_ids)
    return str(path.resolve())
