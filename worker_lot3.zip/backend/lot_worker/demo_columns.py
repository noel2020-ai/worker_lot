"""Fictional extra columns used only by the seed-demo table."""

DEMO_EXTRA_COLUMNS = (
    "PostalCode", "Country", "AccountNumber", "AccountStatus", "AccountType", "ParentAccountID",
    "LegalName", "TradingName", "AddressLine2", "Building", "Floor", "Unit", "District", "Region",
    "Latitude", "Longitude", "Phone", "Email", "Website", "Industry", "EmployeeCount", "AnnualRevenue",
    "Currency", "CreatedAt", "UpdatedAt", "ExternalReference",
)
