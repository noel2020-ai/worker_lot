from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import Attempt, PacketAccount, PacketBatch, PacketTask


def daily_used(session, day):
    return (session.scalar(select(func.count()).select_from(Attempt).where(Attempt.run_date == day))
            + session.scalar(select(func.count()).select_from(PacketTask).where(PacketTask.run_date == day)))


def packet_progress(engine, settings, batch_id: str | None = None) -> dict:
    day = datetime.now(ZoneInfo(settings.timezone)).date()
    with Session(engine) as session:
        used = daily_used(session, day)
        batches_query = select(PacketBatch).order_by(PacketBatch.created_at, PacketBatch.id)
        if batch_id:
            batches_query = batches_query.where(PacketBatch.id == batch_id)
        batches = []
        for batch in session.scalars(batches_query):
            routing = dict(session.execute(select(PacketAccount.routing_status, func.count()).where(
                PacketAccount.batch_id == batch.id).group_by(PacketAccount.routing_status)).all())
            counts = session.execute(select(PacketTask.packet_id, PacketTask.status, func.count()).join(
                PacketAccount, PacketTask.account_id == PacketAccount.id).where(PacketAccount.batch_id == batch.id)
                .group_by(PacketTask.packet_id, PacketTask.status)).all()
            packets = {packet["id"]: {"name": packet["name"], "counts": {}, "total": 0}
                       for packet in batch.configuration["packets"] if packet["enabled"]}
            for packet_id, status, count in counts:
                packets[packet_id]["counts"][status] = count
                packets[packet_id]["total"] += count
            for packet in packets.values():
                pending = sum(packet["counts"].get(state, 0) for state in ("pending", "running"))
                packet["finished"] = packet["total"] - pending
                packet["progress_percent"] = round(100 * packet["finished"] / packet["total"], 1) if packet["total"] else 0
            batches.append({"batch_id": batch.id, "stage": batch.status, "source_accounts": batch.row_count,
                            "routing": routing, "packets": packets, "error_code": batch.error_code})
    return {"day": str(day), "daily_limit": settings.daily_limit, "attempted_today": used,
            "remaining_today": max(0, settings.daily_limit - used), "batches": batches}
