import hashlib
import logging
from uuid import uuid4

from sqlalchemy import update
from sqlalchemy.orm import Session

from .config import Settings
from .locking import exclusive_connection
from .models import PacketAccount, PacketBatch, PacketTask
from .packet_config import load_packet_configuration
from .packet_routing import route_account
from .packet_export import automatic_packet_export
from .source_records import selected_columns, source_mapping, source_records
from .errors import error_details

logger = logging.getLogger(__name__)


def save_account(session: Session, batch_id: str, record: dict, configuration) -> None:
    segregation = route_account(record["company_name"], configuration)
    account = PacketAccount(batch_id=batch_id, source_id=record["source_id"], source_record=record,
                            source_key=hashlib.sha256(record["source_id"].encode("utf-8")).hexdigest(),
                            segregation=segregation, routing_status=segregation["status"])
    session.add(account)
    session.flush()
    session.add_all(PacketTask(account_id=account.id, packet_id=packet_id)
                    for packet_id in segregation["packet_ids"])


def packetize(engine, source, settings: Settings) -> dict:
    configuration = load_packet_configuration(settings.packet_config_path)
    mapping = {"schema": settings.source_schema, "table": settings.source_table,
               "columns": selected_columns(settings), "roles": source_mapping(settings)}
    batch_id, count = str(uuid4()), 0
    with exclusive_connection(engine) as lock:
        if lock is None:
            return {"status": "busy", "message": "Another worker is running", "data": {}}
        with Session(lock) as session, session.begin():
            # Interrupted partial snapshots are never eligible for layer 2.
            session.execute(update(PacketBatch).where(PacketBatch.status == "building").values(
                status="failed", error_code="PACKETIZATION_INTERRUPTED"))
            session.add(PacketBatch(id=batch_id, configuration=configuration.model_dump(), source_mapping=mapping))
        try:
            with Session(lock) as session:
                for record in source_records(source, settings):
                    save_account(session, batch_id, record, configuration)
                    count += 1
                    if count % 500 == 0:
                        session.execute(update(PacketBatch).where(PacketBatch.id == batch_id).values(row_count=count))
                        session.commit()
                        logger.info("packetization_progress batch_id=%s rows=%s", batch_id, count)
                session.execute(update(PacketBatch).where(PacketBatch.id == batch_id).values(row_count=count, status="ready"))
                session.commit()
        except Exception as exc:
            with Session(lock) as session, session.begin():
                session.execute(update(PacketBatch).where(PacketBatch.id == batch_id).values(
                    status="failed", error_code=type(exc).__name__))
            logger.error("packetization_failed batch_id=%s error_type=%s", batch_id, type(exc).__name__)
            return {"status": "error", "message": "Packetization failed; partial batch excluded from matching",
                    "data": {"batch_id": batch_id, **error_details(exc, "packetize_source_or_save")}}
    logger.info("packetization_complete batch_id=%s rows=%s", batch_id, count)
    return {"status": "success", "message": "Packetization finished; ready for location matching",
            "data": {"batch_id": batch_id, "source_accounts": count,
                     "output_file": automatic_packet_export(engine, settings.output_root, batch_id)}}
