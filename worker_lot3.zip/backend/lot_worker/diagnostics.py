"""Read-only checks: resolve configured tables and columns without retrieving data."""
from sqlalchemy import select

from .errors import error_details
from .masterfile import master_statement
from .models import Base
from .source_records import source_snapshot_statement


def check_statement(engine, stage, statement_factory):
    try:
        statement = statement_factory().order_by(None).limit(0)
        with engine.connect() as connection:
            connection.execute(statement).close()
        return {"stage": stage, "status": "success"}
    except Exception as exc:
        return {"stage": stage, "status": "error", "error": error_details(exc, stage)}


def check_databases(application, source, master, settings):
    checks = [check_statement(application, f"application.{table.name}", lambda table=table: select(table))
              for table in Base.metadata.sorted_tables]
    checks.append(check_columns(source, "source_columns", lambda: source_snapshot_statement(settings)))
    checks.append(check_columns(master if master is not None else source, "master_columns", lambda: master_statement(settings)))
    failed = any(check["status"] == "error" for check in checks)
    return {"status": "error" if failed else "success",
            "message": "Database checks found errors" if failed else "Configured tables and columns are readable",
            "data": {"checks": checks, "scope": "Read-only schema checks; writes, locks, and matching were not tested"}}


def check_columns(engine, stage, statement_factory):
    check = check_statement(engine, stage, statement_factory)
    if check.get("error", {}).get("category") == "invalid_column":
        statement = statement_factory()
        failures = []
        for column in statement.selected_columns:
            probe = check_statement(engine, stage, lambda column=column: statement.with_only_columns(column))
            if probe["status"] == "error":
                # Names come from validated configuration, never from driver error text.
                failures.append({"column": getattr(getattr(column, "element", column), "name"),
                                 "error": probe["error"]})
        check["failing_columns"] = failures
    return check
