import logging

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy.orm import Session

from .config import Settings
from .ingestion import add_names, input_path, load_names
from .locking import exclusive_connection
from .models import Base, DemoAccount, DemoBase, DemoCompany
from .demo_columns import DEMO_EXTRA_COLUMNS

logger = logging.getLogger(__name__)


class DemoRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    CompanyID: int = Field(gt=0)
    CompanyName: str = Field(min_length=1, max_length=500)
    Address: str = Field(max_length=1000)
    City: str = Field(default="", max_length=200)
    State: str = Field(default="", max_length=200)
    Province: str = Field(default="", max_length=200)

    @model_validator(mode="after")
    def valid_extra_columns(self):
        for name, value in (self.model_extra or {}).items():
            if name not in DEMO_EXTRA_COLUMNS or not isinstance(value, str) or len(value) > 500:
                raise ValueError("Unknown or invalid dummy source column")
        return self


class DemoAccountRecord(BaseModel):
    RowID: int = Field(gt=0)
    AccountID: str = Field(min_length=1, max_length=100)
    Address: str = Field(min_length=1, max_length=1000)
    City: str = Field(max_length=200)
    State: str = Field(max_length=200)
    Province: str = Field(max_length=200)


def load_demo_accounts(settings: Settings) -> list[DemoAccountRecord]:
    path = input_path(settings, settings.demo_master_file)
    if path.suffix.lower() != ".csv":
        raise ValueError("Demo masterfile must be CSV")
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    records = [DemoAccountRecord.model_validate(row) for row in frame.to_dict(orient="records")]
    if len({row.RowID for row in records}) != len(records):
        raise ValueError("Duplicate demo masterfile row IDs")
    if any(not row.AccountID.strip() or not row.Address.strip() for row in records):
        raise ValueError("Demo account ID and address must not be blank")
    return records


def load_demo_records(settings: Settings) -> list[DemoRecord]:
    path = input_path(settings, settings.demo_company_file)
    if path.suffix.lower() != ".csv":
        raise ValueError("Demo company file must be CSV")
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    records = [DemoRecord.model_validate(row) for row in frame.to_dict(orient="records")]
    if len({row.CompanyID for row in records}) != len(records):
        raise ValueError("Duplicate demo company IDs")
    if any(not row.CompanyName.strip() for row in records):
        raise ValueError("Demo company names cannot be blank")
    return records


def insert_records(session: Session, records: list, model, id_field: str) -> int:
    added = 0
    for record in records:
        existing = session.get(model, getattr(record, id_field))
        values = record.model_dump()
        if existing is not None:
            if any(getattr(existing, key) != value for key, value in values.items()):
                raise ValueError("Demo ID already exists with different data")
            continue
        session.add(model(**values))
        added += 1
    session.flush()
    return added


def insert_demo_records(session: Session, records: list[DemoRecord]) -> int:
    return insert_records(session, records, DemoCompany, "CompanyID")


def seed_demo(engine, settings: Settings) -> dict:
    records = load_demo_records(settings)
    accounts = load_demo_accounts(settings)
    names = load_names(settings)
    with exclusive_connection(engine) as connection:
        if connection is None:
            raise RuntimeError("Another worker or import is running; try again later")
        Base.metadata.create_all(connection)
        DemoBase.metadata.create_all(connection)
        connection.commit()
        with Session(connection) as session, session.begin():
            companies_added = insert_demo_records(session, records)
            accounts_added = insert_records(session, accounts, DemoAccount, "RowID")
            names_added = add_names(session, names)
    logger.info("demo_seed_complete companies_added=%s accounts_added=%s names_added=%s", companies_added, accounts_added, names_added)
    return {"companies_added": companies_added, "accounts_added": accounts_added, "names_added": names_added}
