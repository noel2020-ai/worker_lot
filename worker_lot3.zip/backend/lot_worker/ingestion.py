import logging

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import Settings
from .matching import normalize_name
from .models import Job
from .locking import exclusive_connection

logger = logging.getLogger(__name__)


def input_path(settings: Settings, filename: str):
    root = settings.input_root.resolve(strict=True)
    candidate = root / filename
    path = candidate.resolve(strict=True)
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError("Input must be a file within INPUT_ROOT")
    if path.suffix.lower() not in {".csv", ".xlsx"}:
        raise ValueError("Only .csv and .xlsx input files are supported")
    return path


def load_names(settings: Settings) -> list[str]:
    path = input_path(settings, settings.input_file)
    if path.suffix.lower() == ".csv":
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    elif path.suffix.lower() == ".xlsx":
        frame = pd.read_excel(path, sheet_name=settings.input_sheet, dtype=str, keep_default_na=False, engine="openpyxl")
    else:
        raise ValueError("Only .csv and .xlsx input files are supported")
    if settings.input_name_column not in frame.columns:
        raise ValueError("Configured input name column is missing")
    names = {}
    for value in frame[settings.input_name_column]:
        name = str(value).strip()
        if not name:
            continue
        if len(name) > 500:
            raise ValueError("Company name exceeds 500 characters")
        names.setdefault(normalize_name(name), name)
    return list(names.values())


def add_names(session: Session, names: list[str]) -> int:
    added = 0
    for name in names:
        normalized = normalize_name(name)
        if session.scalar(select(Job.id).where(Job.normalized_name == normalized)) is None:
            session.add(Job(name=name, normalized_name=normalized))
            session.flush()
            added += 1
    return added


def ingest(engine, settings: Settings) -> int:
    names = load_names(settings)
    with exclusive_connection(engine) as connection:
        if connection is None:
            raise RuntimeError("Another worker or import is running; try again later")
        with Session(connection) as session, session.begin():
            added = add_names(session, names)
    logger.info("ingestion_complete added=%s input_unique=%s", added, len(names))
    return added
