from sqlalchemy import create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.sql import Select

from .config import Settings


def application_engine(settings: Settings):
    url = make_url(settings.database_url.get_secret_value())
    if url.drivername != "mssql+pyodbc":
        raise ValueError("DATABASE_URL must use mssql+pyodbc")
    engine = create_engine(url, pool_pre_ping=True, hide_parameters=True,
                           connect_args={"timeout": settings.source_timeout_seconds})

    @event.listens_for(engine, "connect")
    def query_timeout(dbapi_connection, connection_record):
        dbapi_connection.timeout = settings.source_timeout_seconds

    return engine


def source_engine(settings: Settings, database_url=None):
    url = make_url((database_url or settings.source_database_url).get_secret_value())
    if url.drivername != "mssql+pyodbc":
        raise ValueError("SOURCE_DATABASE_URL must use mssql+pyodbc")
    engine = create_engine(url, hide_parameters=True, connect_args={"timeout": settings.source_timeout_seconds})

    @event.listens_for(engine, "connect")
    def query_timeout(dbapi_connection, connection_record):
        dbapi_connection.timeout = settings.source_timeout_seconds

    @event.listens_for(engine, "before_execute")
    def select_only(connection, clauseelement, multiparams, params, execution_options):
        # Accept only the worker's constructed SELECT; arbitrary SQL is never accepted.
        if not isinstance(clauseelement, Select):
            raise ValueError("External source accepts constructed SELECT statements only")

    return engine
