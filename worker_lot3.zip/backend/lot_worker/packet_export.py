import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import PacketAccount, PacketBatch, PacketTask


def packet_export_payload(engine, batch_id: str | None = None, task_ids: list[int] | None = None) -> dict:
    with Session(engine) as session:
        batch_query = select(PacketBatch).order_by(PacketBatch.created_at, PacketBatch.id)
        if batch_id:
            batch_query = batch_query.where(PacketBatch.id == batch_id)
        if task_ids is not None:
            included = select(PacketAccount.batch_id).join(PacketTask, PacketTask.account_id == PacketAccount.id).where(PacketTask.id.in_(task_ids))
            batch_query = batch_query.where(PacketBatch.id.in_(included))
        batches = []
        for batch in session.scalars(batch_query):
            packets = {packet["id"]: {"packet_id": packet["id"], "packet_name": packet["name"],
                                      "matching_rules": packet["matching"], "account_ids": [], "accounts": []}
                       for packet in batch.configuration["packets"] if packet["enabled"]}
            query = select(PacketAccount, PacketTask).join(PacketTask, PacketTask.account_id == PacketAccount.id).where(
                PacketAccount.batch_id == batch.id).order_by(PacketTask.id)
            if task_ids is not None:
                query = query.where(PacketTask.id.in_(task_ids))
            for account, task in session.execute(query):
                packets[task.packet_id]["accounts"].append({"task_id": task.id, "source": account.source_record,
                    "segregation": account.segregation, "status": task.status,
                    "run_date": str(task.run_date) if task.run_date else None,
                    "match_result": task.result, "error_code": task.error_code})
            for packet in packets.values():
                packet["account_ids"] = sorted({account_id for account in packet["accounts"]
                    for account_id in (account["match_result"] or {}).get("account_ids", [])})
            review = []
            if task_ids is None:
                review = [{"source": account.source_record, "segregation": account.segregation}
                          for account in session.scalars(select(PacketAccount).where(
                              PacketAccount.batch_id == batch.id, PacketAccount.routing_status != "assigned").order_by(PacketAccount.id))]
            batches.append({"batch_id": batch.id, "stage": batch.status, "source_mapping": batch.source_mapping,
                            "configuration": batch.configuration, "source_account_count": batch.row_count,
                            "packets": list(packets.values()), "unassigned_or_ambiguous": review,
                            "error_code": batch.error_code})
    return {"format_version": "packets-v1", "export_scope": "attempted_tasks" if task_ids is not None else "batch_snapshot",
            "generated_at": datetime.now(timezone.utc).isoformat(), "batches": batches}


def export_packets(engine, path: Path, batch_id: str | None = None, task_ids: list[int] | None = None) -> dict:
    payload = packet_export_payload(engine, batch_id, task_ids)
    with path.open("x", encoding="utf-8") as output:
        json.dump(payload, output, indent=2, ensure_ascii=False, allow_nan=False)
    return {"output_file": str(path.resolve()), "batches": len(payload["batches"])}


def automatic_packet_export(engine, output_root: Path, batch_id=None, task_ids=None) -> str:
    output_root.mkdir(parents=True, exist_ok=True)
    prefix = "packets" if task_ids is None else "packet-matches"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = output_root / f"{prefix}-{stamp}-{uuid4().hex}.json"
    return export_packets(engine, path, batch_id, task_ids)["output_file"]
