from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, JSON, String, Unicode, UniqueConstraint, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from .demo_columns import DEMO_EXTRA_COLUMNS


class Base(DeclarativeBase):
    pass


class Job(Base):
    __tablename__ = "lot_search_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(Unicode(500))
    normalized_name: Mapped[str] = mapped_column(Unicode(500), unique=True)
    status: Mapped[str] = mapped_column(String(30), default="pending", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Attempt(Base):
    __tablename__ = "lot_search_attempts"
    __table_args__ = (UniqueConstraint("job_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("lot_search_jobs.id"), index=True)
    run_date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(30), default="running")
    match_mode: Mapped[str] = mapped_column(String(30))
    results: Mapped[list] = mapped_column(JSON, default=list)
    truncated: Mapped[bool] = mapped_column(default=False)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PacketBatch(Base):
    __tablename__ = "lot_packet_batches"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    status: Mapped[str] = mapped_column(String(30), default="building", index=True)
    configuration: Mapped[dict] = mapped_column(JSON)
    source_mapping: Mapped[dict] = mapped_column(JSON)
    row_count: Mapped[int] = mapped_column(default=0)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class PacketAccount(Base):
    __tablename__ = "lot_packet_accounts"
    __table_args__ = (UniqueConstraint("batch_id", "source_key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[str] = mapped_column(ForeignKey("lot_packet_batches.id"), index=True)
    source_key: Mapped[str] = mapped_column(String(64))
    source_id: Mapped[str] = mapped_column(Unicode(500))
    source_record: Mapped[dict] = mapped_column(JSON)
    segregation: Mapped[dict] = mapped_column(JSON)
    routing_status: Mapped[str] = mapped_column(String(30), index=True)


class PacketTask(Base):
    __tablename__ = "lot_packet_tasks"
    __table_args__ = (UniqueConstraint("account_id", "packet_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("lot_packet_accounts.id"), index=True)
    packet_id: Mapped[str] = mapped_column(String(64), index=True)
    status: Mapped[str] = mapped_column(String(30), default="pending", index=True)
    run_date: Mapped[date | None] = mapped_column(Date, nullable=True, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)


class DemoBase(DeclarativeBase):
    pass


class DemoCompany(DemoBase):
    __tablename__ = "lot_demo_companies"
    CompanyID: Mapped[int] = mapped_column(primary_key=True, autoincrement=False)
    CompanyName: Mapped[str] = mapped_column(Unicode(500))
    Address: Mapped[str | None] = mapped_column(Unicode(1000), nullable=True)
    City: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)
    State: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)
    Province: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)


class DemoAccount(DemoBase):
    __tablename__ = "lot_demo_accounts"
    RowID: Mapped[int] = mapped_column(primary_key=True, autoincrement=False)
    AccountID: Mapped[str] = mapped_column(Unicode(100))
    Address: Mapped[str] = mapped_column(Unicode(1000))
    City: Mapped[str] = mapped_column(Unicode(200))
    State: Mapped[str] = mapped_column(Unicode(200))
    Province: Mapped[str] = mapped_column(Unicode(200))


# Production selection never uses this model; its 32 columns are an editable JSON list.
for _column in DEMO_EXTRA_COLUMNS:
    setattr(DemoCompany, _column, mapped_column(Unicode(500), nullable=True))
