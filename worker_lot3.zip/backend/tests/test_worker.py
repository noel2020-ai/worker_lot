from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.dialects import mssql
from sqlalchemy.orm import Session

from lot_worker.config import Settings
from lot_worker.ingestion import load_names
from lot_worker.matching import find_matches, search_statement, valid_address
from lot_worker.models import Attempt, Base, Job
from lot_worker.worker import claim_job, finish_job


@pytest.fixture
def settings(tmp_path):
    return Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                    source_database_url="mssql+pyodbc://unused/unused",
                    source_table="Companies", source_id_column="ID", source_name_column="Name",
                    source_address_column="Address", input_root=tmp_path, input_file="names.csv")


@pytest.mark.parametrize("address", [None, "", " \t\n", "PO Box 1", "p.o. box 42", "P O BOX123", "POBOX 5", "Post Office Box 7", "Office, PO Box 2"])
def test_reject_addresses(address):
    assert not valid_address(address)


@pytest.mark.parametrize("address", ["12 Main Street", "3 Boxwood Road", "10 Poblacion Avenue"])
def test_accept_street_addresses(address):
    assert valid_address(address)


def test_names_are_deduplicated_and_missing_cells_skipped(settings):
    (settings.input_root / "names.csv").write_text('CompanyName,Other\nAcme,A\n ACME ,B\n,C\nBeta,D\n', encoding="utf-8")
    assert load_names(settings) == ["Acme", "Beta"]


def test_excel_input(settings):
    import pandas as pd

    settings.input_file = "names.xlsx"
    pd.DataFrame({"CompanyName": ["Acme", "Beta"]}).to_excel(
        settings.input_root / settings.input_file, sheet_name=settings.input_sheet, index=False)
    assert load_names(settings) == ["Acme", "Beta"]


def test_path_traversal_rejected(settings, tmp_path):
    outside = tmp_path.parent / "outside.csv"
    outside.write_text("CompanyName\nAcme\n", encoding="utf-8")
    settings.input_file = "../outside.csv"
    with pytest.raises(ValueError, match="within INPUT_ROOT"):
        load_names(settings)


@pytest.mark.parametrize("mode,expected", [("exact", "o'reilly%_["), ("contains", "%o'reilly~%~_~[%"), ("starts_with", "o'reilly~%~_~[%")])
def test_sql_is_parameterized_and_wildcards_literal(settings, mode, expected):
    settings.match_mode = mode
    compiled = search_statement(settings, "O'Reilly%_[").compile(dialect=mssql.dialect())
    assert expected in compiled.params.values()
    assert "O'Reilly" not in str(compiled)
    assert str(compiled).startswith("SELECT")
    assert ";" not in str(compiled)


def test_invalid_addresses_do_not_consume_result_cap(settings):
    settings.max_results = 1

    class Result:
        closed = False

        def mappings(self):
            return iter([{"source_id": n, "company_name": "Acme", "address": address,
                          "city": "Test City", "state": "Test State", "province": "Test Province"}
                         for n, address in enumerate(["PO Box 1", "  ", "1 Main Street", "2 Main Street"])])

        def close(self):
            self.closed = True

    result = Result()

    class Connection:
        def execution_options(self, **kwargs):
            return self

        def execute(self, statement):
            return result

    rows, truncated = find_matches(Connection(), settings, "Acme")
    assert [row["address"] for row in rows] == ["1 Main Street"]
    assert truncated and result.closed


def test_quota_counts_failed_and_unfinished_attempts_after_restart(settings, tmp_path):
    settings.daily_limit = 2
    url = f"sqlite:///{(tmp_path / 'test.db').as_posix()}"
    engine = create_engine(url)
    Base.metadata.create_all(engine)
    with Session(engine) as session, session.begin():
        session.add_all([Job(name=name, normalized_name=name) for name in ["a", "b", "c"]])
    first = claim_job(engine, settings)
    finish_job(engine, first[0], first[2], "failed", [], error_code="TEST")
    assert claim_job(engine, settings) is not None
    engine.dispose()
    restarted = create_engine(url)
    assert claim_job(restarted, settings) is None
    with Session(restarted) as session:
        attempts = session.scalars(select(Attempt)).all()
        assert len(attempts) == 2
        assert all(item.run_date == datetime.now(ZoneInfo(settings.timezone)).date() for item in attempts)
    restarted.dispose()


def test_new_day_has_new_allowance(settings):
    settings.daily_limit = 1
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with Session(engine) as session, session.begin():
        old_job = Job(name="old", normalized_name="old", status="matched")
        session.add(old_job)
        session.flush()
        session.add(Attempt(job_id=old_job.id, status="matched", match_mode="exact",
                            run_date=datetime.now(ZoneInfo(settings.timezone)).date() - timedelta(days=1)))
        session.add(Job(name="new", normalized_name="new"))
    assert claim_job(engine, settings) is not None
    assert claim_job(engine, settings) is None
    engine.dispose()
