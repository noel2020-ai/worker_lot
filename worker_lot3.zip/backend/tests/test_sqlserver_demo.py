from contextlib import contextmanager
import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.dialects import mssql
from sqlalchemy.orm import Session
from sqlalchemy.schema import CreateTable

from lot_worker.config import Settings
from lot_worker.demo import seed_demo
from lot_worker.locking import exclusive_connection
from lot_worker.models import Attempt, Base, DemoCompany, Job
from lot_worker.worker import process_queue


@pytest.mark.parametrize("code,acquired", [(0, True), (1, True), (-1, False)])
def test_application_lock_release(code, acquired):
    engine = MagicMock()
    connection = engine.connect.return_value.__enter__.return_value
    connection.scalar.side_effect = [code, 0]
    with exclusive_connection(engine) as result:
        assert (result is not None) is acquired
    assert connection.scalar.call_count == (2 if acquired else 1)


@pytest.mark.parametrize("code", [-2, -3, -999])
def test_application_lock_errors_are_not_busy(code):
    engine = MagicMock()
    connection = engine.connect.return_value.__enter__.return_value
    connection.scalar.return_value = code
    with pytest.raises(RuntimeError):
        with exclusive_connection(engine):
            pytest.fail("Must not enter critical section")
    connection.invalidate.assert_called_once()


def test_release_failure_discards_locked_connection():
    engine = MagicMock()
    connection = engine.connect.return_value.__enter__.return_value
    connection.scalar.side_effect = [0, -999]
    with pytest.raises(RuntimeError):
        with exclusive_connection(engine):
            pass
    connection.invalidate.assert_called_once()


def test_sql_server_schema_compiles():
    statements = [str(CreateTable(table).compile(dialect=mssql.dialect())) for table in Base.metadata.sorted_tables]
    assert any("IDENTITY" in sql for sql in statements)
    assert any("NVARCHAR" in sql for sql in statements)


def test_demo_seed_matching_and_repeat_run(monkeypatch, tmp_path):
    settings = Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                        source_database_url="mssql+pyodbc://unused/unused", source_schema="main",
                        source_table="lot_demo_companies", source_id_column="CompanyID",
                        source_name_column="CompanyName", source_address_column="Address",
                        input_root=Path(__file__).resolve().parents[2] / "examples",
                        input_file="dummy_names.csv", master_schema="main", output_root=tmp_path / "output")
    engine = create_engine(f"sqlite:///{(tmp_path / 'demo.db').as_posix()}")

    @contextmanager
    def test_lock(engine):
        with engine.connect() as connection:
            yield connection

    monkeypatch.setattr("lot_worker.demo.exclusive_connection", test_lock)
    monkeypatch.setattr("lot_worker.worker.exclusive_connection", test_lock)
    assert seed_demo(engine, settings) == {"companies_added": 23, "accounts_added": 13, "names_added": 12}
    assert seed_demo(engine, settings) == {"companies_added": 0, "accounts_added": 0, "names_added": 0}
    settings.master_max_rows = 1
    with pytest.raises(ValueError, match="MASTER_MAX_ROWS"):
        process_queue(engine, engine, settings)
    with Session(engine) as session:
        assert session.scalar(select(func.count()).select_from(Attempt)) == 0
    settings.master_max_rows = 250000
    result = process_queue(engine, engine, settings)
    assert result["data"]["attempted"] == 12
    assert result["data"]["failed"] == 0
    exported = json.loads(Path(result["data"]["output_file"]).read_text(encoding="utf-8"))
    amazon = next(row for row in exported if row["input_name"] == "Amazon")
    assert amazon["account_ids"] == ["000101", "000102"]
    assert amazon["matches"][0]["company_name"] == "102AMAZON"
    assert amazon["matches"][0]["multiple_accounts"]
    facebook = next(row for row in exported if row["input_name"] == "Facebook")
    assert facebook["account_ids"] == ["000201"]
    assert facebook["matches"][0]["company_name"] == "FACEBOOK-BLDG1"
    assert process_queue(engine, engine, settings)["data"]["attempted"] == 0
    with Session(engine) as session:
        statuses = dict(session.execute(select(Job.status, func.count()).group_by(Job.status)).all())
        assert statuses == {"matched": 7, "no_match": 5}
        assert sum(len(row.results) for row in session.scalars(select(Attempt))) == 10
        assert session.scalar(select(func.count()).select_from(DemoCompany)) == 23
    with Session(engine) as session, session.begin():
        session.add(Job(name="Demo Unlinked", normalized_name="demo unlinked"))
        session.add(DemoCompany(CompanyID=100, CompanyName="Demo Unlinked", Address="999 Unlisted Road",
                                City="Sample City", State="Example State", Province="Example Province"))
    unmatched_run = process_queue(engine, engine, settings)
    unmatched_export = json.loads(Path(unmatched_run["data"]["output_file"]).read_text(encoding="utf-8"))
    assert len(unmatched_export) == 1
    assert unmatched_export[0]["status"] == "no_account_match"
    assert unmatched_export[0]["account_ids"] == []
    assert len(unmatched_export[0]["matches"]) == 1
    assert unmatched_export[0]["matches"][0]["no_match_reason"] == "no_master_location_met_rules"
    engine.dispose()
