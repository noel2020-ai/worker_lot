import json

import pytest
from sqlalchemy import create_engine, event, select, literal
from sqlalchemy.exc import ProgrammingError
from sqlalchemy.sql import Select

from lot_worker.config import Settings
from lot_worker.diagnostics import check_columns, check_databases, check_statement
from lot_worker.errors import error_details
from lot_worker.models import Base, DemoBase
from lot_worker.source_records import source_snapshot_statement


@pytest.mark.parametrize("code,category", [(207, "invalid_column"), (208, "missing_table"), (229, "permission_denied")])
def test_sql_error_diagnostics_do_not_expose_driver_secrets(code, category):
    original = Exception("42000", f"Password=TOP_SECRET; mssql://login:PRIVATE@host/database ({code})")
    error = ProgrammingError("SQL_WITH_PRIVATE_DATA", {"password": "HIDDEN"}, original)
    details = error_details(error, "packetize")
    assert details["category"] == category
    assert details["native_code"] == code
    assert details["sqlstate"] == "42000"
    serialized = json.dumps(details)
    for secret in ("TOP_SECRET", "PRIVATE", "HIDDEN", "SQL_WITH_PRIVATE_DATA", "mssql://"):
        assert secret not in serialized


def test_unknown_error_is_not_guessed_or_exposed():
    details = error_details(RuntimeError("secret data"), "run")
    assert details["category"] == "unclassified_error"
    assert details["sqlstate"] is None
    assert "secret data" not in json.dumps(details)


def test_zero_row_checks_use_only_select_and_do_not_modify_database():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    DemoBase.metadata.create_all(engine)
    settings = Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                        source_database_url="mssql+pyodbc://unused/unused", source_schema="main", master_schema="main")
    statements = []

    @event.listens_for(engine, "before_execute")
    def inspect_read_only(connection, statement, multiparams, params, execution_options):
        assert isinstance(statement, Select)
        assert statement._limit_clause.value == 0
        statements.append(statement)

    result = check_databases(engine, engine, None, settings)
    assert result["status"] == "success"
    assert len(statements) == len(Base.metadata.tables) + 2
    engine.dispose()


def test_missing_application_tables_report_individual_failures():
    engine = create_engine("sqlite://")
    settings = Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                        source_database_url="mssql+pyodbc://unused/unused", source_schema="main", master_schema="main")
    result = check_databases(engine, engine, None, settings)
    assert result["status"] == "error"
    assert any(check["stage"] == "application.lot_packet_batches" and check["status"] == "error"
               for check in result["data"]["checks"])
    engine.dispose()


def test_source_check_identifies_bad_configured_column():
    engine = create_engine("sqlite://")
    DemoBase.metadata.create_all(engine)
    settings = Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                        source_database_url="mssql+pyodbc://unused/unused", source_schema="main",
                        source_extra_columns=["MissingColumn"])

    @event.listens_for(engine, "before_execute")
    def simulate_sqlserver_error(connection, statement, multiparams, params, execution_options):
        if "MissingColumn" in statement.selected_columns.keys():
            raise ProgrammingError("private SQL", {}, Exception("42S22", "Invalid column name (207)"))

    result = check_columns(engine, "source_columns", lambda: source_snapshot_statement(settings))
    assert result["status"] == "error"
    assert [column["column"] for column in result["failing_columns"]] == ["MissingColumn"]
    engine.dispose()
