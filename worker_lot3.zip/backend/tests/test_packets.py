import json
from contextlib import contextmanager
from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError
from sqlalchemy import func, select, update
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from lot_worker.config import Settings
from lot_worker.demo import seed_demo
from lot_worker.models import DemoCompany, PacketAccount, PacketBatch, PacketTask
from lot_worker.packet_config import MatchingRules, PacketConfiguration, load_packet_configuration
from lot_worker.packet_export import packet_export_payload
from lot_worker.packet_locations import compare_packet_location
from lot_worker.packet_progress import packet_progress
from lot_worker.packet_routing import route_account
from lot_worker.packet_worker import process_packets
from lot_worker.packetizing import packetize
from lot_worker.source_records import json_value, selected_columns

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def packet_environment(tmp_path, monkeypatch):
    settings = Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                        source_database_url="mssql+pyodbc://unused/unused", source_schema="main", master_schema="main",
                        input_root=ROOT / "examples", input_file="dummy_names.csv", output_root=tmp_path / "output",
                        packet_config_path=ROOT / "config/packets.json", source_columns_path=ROOT / "config/source_columns.json")
    engine = create_engine(f"sqlite:///{(tmp_path / 'packets.db').as_posix()}")

    @contextmanager
    def test_lock(engine):
        with engine.connect() as connection:
            yield connection

    for module in ("demo", "packetizing", "packet_worker"):
        monkeypatch.setattr(f"lot_worker.{module}.exclusive_connection", test_lock)
    seed_demo(engine, settings)
    yield engine, settings
    engine.dispose()


@pytest.mark.parametrize("name", ["123Amazon", "AWSAmzn", "ORD01AMZN", "TX-001Amzn"])
def test_requested_aliases_route_to_amazon(name):
    rules = load_packet_configuration(ROOT / "config/packets.json")
    assert route_account(name, rules)["packet_ids"] == ["amazon"]
    assert len(rules.packets) == 14


def test_multiple_memberships_and_exclusions():
    rules = load_packet_configuration(ROOT / "config/packets.json")
    result = route_account("Amazon Cedar Shared", rules)
    assert result["packet_ids"] == ["amazon", "cedar"]
    amended = rules.model_dump()
    amended["packets"][0]["exclude"] = [{"mode": "contains", "value": "Shared"}]
    assert route_account("Amazon Cedar Shared", PacketConfiguration.model_validate(amended))["packet_ids"] == ["cedar"]


def test_packet_rules_change_matching_independently():
    source = {"address": "100 Example Street", "city": "City A", "state": "State", "province": "Province"}
    master = {**source, "city": "City B"}
    strict = MatchingRules()
    assert compare_packet_location(source, master, strict) is None
    alternate = strict.model_dump()
    alternate["fields"]["city"] = {"mode": "ignore", "required": False, "weight": 0}
    alternate["fields"]["province"] = {"mode": "exact", "required": True, "weight": 20}
    evidence = compare_packet_location(source, master, MatchingRules.model_validate(alternate))
    assert evidence["confidence_score"] == 94
    assert evidence["ignored_fields"] == ["city"]
    assert evidence["confidence_level"] == "medium"


def test_two_layers_snapshot_all_columns_overlap_quota_and_progress(packet_environment):
    engine, settings = packet_environment
    segregated = packetize(engine, engine, settings)
    assert segregated["status"] == "success"
    batch_id = segregated["data"]["batch_id"]
    snapshot = packet_export_payload(engine, batch_id)["batches"][0]
    assert len(snapshot["packets"]) == 14
    assert snapshot["source_account_count"] == 23
    amazon = next(packet for packet in snapshot["packets"] if packet["packet_id"] == "amazon")
    assert len(amazon["accounts"]) == 6
    assert all(account["status"] == "pending" and account["match_result"] is None for account in amazon["accounts"])
    assert all(len(account["source"]["source_data"]) == 32 for account in amazon["accounts"])
    assert amazon["accounts"][0]["source"]["source_data"]["AccountNumber"] == "DEMO-00013"
    assert len(snapshot["unassigned_or_ambiguous"]) == 1
    assert packet_progress(engine, settings)["attempted_today"] == 0

    # Layer 2 must use the saved account and rules, never reload changing source rows.
    with engine.begin() as connection:
        connection.execute(update(DemoCompany).where(DemoCompany.CompanyID == 13).values(City="Changed After Packetization"))
    settings.daily_limit = 2
    unavailable_source = MagicMock()
    unavailable_source.connect.side_effect = AssertionError("Source must not be read by layer 2")
    first = process_packets(engine, unavailable_source, settings, master_source=engine, batch_id=batch_id)
    assert first["data"]["attempted"] == 2
    assert process_packets(engine, unavailable_source, settings, master_source=engine)["data"]["attempted"] == 0
    progress = packet_progress(engine, settings, batch_id)
    assert progress["attempted_today"] == 2 and progress["remaining_today"] == 0

    settings.daily_limit = 100
    completed = process_packets(engine, unavailable_source, settings, master_source=engine)
    assert completed["data"]["attempted"] == 21
    snapshot = packet_export_payload(engine, batch_id)["batches"][0]
    amazon = next(packet for packet in snapshot["packets"] if packet["packet_id"] == "amazon")
    assert amazon["account_ids"] == ["000101", "000102"]
    assert amazon["accounts"][0]["match_result"]["city"] == "Sample City"
    progress = packet_progress(engine, settings, batch_id)
    assert progress["batches"][0]["packets"]["amazon"]["progress_percent"] == 100
    assert progress["batches"][0]["packets"]["amazon"]["total"] == 6
    assert process_packets(engine, unavailable_source, settings, master_source=engine)["data"]["attempted"] == 0
    with Session(engine) as session:
        assert session.scalar(select(func.count()).select_from(PacketTask).where(PacketTask.status == "excluded_address")) == 6


def test_failed_partial_packetization_never_matches(packet_environment):
    engine, settings = packet_environment
    settings.source_max_rows = 2
    result = packetize(engine, engine, settings)
    assert result["status"] == "error"
    batch_id = result["data"]["batch_id"]
    with Session(engine) as session:
        assert session.get(PacketBatch, batch_id).status == "failed"
    assert process_packets(engine, engine, settings)["data"]["attempted"] == 0


def test_column_list_requires_mapped_fields(packet_environment, tmp_path):
    _, settings = packet_environment
    assert len(selected_columns(settings)) == 32
    path = tmp_path / "columns.json"
    path.write_text('["CompanyID", "CompanyName"]', encoding="utf-8")
    settings.source_columns_path = path
    with pytest.raises(ValueError, match="six mapped"):
        selected_columns(settings)


def test_precise_source_types_survive_json():
    data = {"Revenue": json_value(Decimal("1234567890.123456789")), "Date": json_value(date(2026, 9, 22)),
            "Null": json_value(None), "Binary": json_value(b"\x00\x01")}
    decoded = json.loads(json.dumps(data))
    assert decoded["Revenue"] == "1234567890.123456789"
    assert decoded["Date"] == "2026-09-22"
    assert decoded["Null"] is None
    assert decoded["Binary"] == {"encoding": "base64", "value": "AAE="}


def test_invalid_rule_weights_rejected():
    config = MatchingRules().model_dump()
    config["fields"]["city"]["weight"] = 100
    with pytest.raises(ValidationError):
        MatchingRules.model_validate(config)
