import argparse
import json
import logging
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .config import Settings
from .database import application_engine, source_engine
from .demo import seed_demo
from .exporting import export_results
from .ingestion import ingest
from .models import Base, Job
from .worker import process_queue
from .packetizing import packetize
from .packet_worker import process_packets
from .packet_export import export_packets
from .packet_progress import packet_progress


def main():
    parser = argparse.ArgumentParser(description="Company search worker")
    parser.add_argument("command", choices=["init-db", "seed-demo", "ingest", "packetize", "run",
                                            "run-legacy", "status", "export", "export-legacy"])
    parser.add_argument("--output", type=Path, help="JSON export destination (must not exist)")
    parser.add_argument("--batch-id", help="Limit packet matching, status, or export to a saved batch")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    engine = source = master = None
    try:
        settings = Settings()
        engine = application_engine(settings)
        if args.command == "init-db":
            Base.metadata.create_all(engine)
            data = {"message": "Worker tables created"}
        elif args.command == "seed-demo":
            data = seed_demo(engine, settings)
        elif args.command == "ingest":
            data = {"added": ingest(engine, settings)}
        elif args.command == "packetize":
            source = source_engine(settings)
            result = packetize(engine, source, settings)
            print(json.dumps(result))
            return 1 if result["status"] == "error" else 0
        elif args.command in ("run", "run-legacy"):
            source = source_engine(settings)
            if settings.master_database_url is not None:
                master = source_engine(settings, settings.master_database_url)
            result = (process_packets(engine, source, settings, master_source=master, batch_id=args.batch_id)
                      if args.command == "run" else process_queue(engine, source, settings, master_source=master))
            print(json.dumps(result))
            return 1 if result["status"] == "error" else 0
        elif args.command == "status":
            data = packet_progress(engine, settings, args.batch_id)
            with Session(engine) as session:
                data["legacy_queue"] = dict(session.execute(select(Job.status, func.count()).group_by(Job.status)).all())
        else:
            if args.output is None:
                raise ValueError("Export requires --output")
            data = (export_packets(engine, args.output, args.batch_id) if args.command == "export"
                    else {"exported": export_results(engine, args.output)})
        print(json.dumps({"status": "success", "message": "Command completed", "data": data}))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "error", "message": "Command failed; check configuration, files and database access",
                          "data": {"error_type": type(exc).__name__}}))
        return 1
    finally:
        if master is not None:
            master.dispose()
        if source is not None:
            source.dispose()
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
