import logging
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .config import Settings
from .matching import find_matches
from .models import Attempt, Job
from .locking import exclusive_connection
from .masterfile import load_master_index
from .exporting import export_run
from .packet_progress import daily_used

logger = logging.getLogger(__name__)


def claim_job(engine, settings: Settings):
    day = datetime.now(ZoneInfo(settings.timezone)).date()
    with Session(engine) as session, session.begin():
        used = daily_used(session, day)
        if used >= settings.daily_limit:
            return None
        job = session.scalar(select(Job).where(Job.status == "pending").order_by(Job.id).limit(1).with_for_update())
        if job is None:
            return None
        job.status = "running"
        attempt = Attempt(job_id=job.id, run_date=day, match_mode=settings.match_mode)
        session.add(attempt)
        session.flush()
        return job.id, job.name, attempt.id


def finish_job(engine, job_id, attempt_id, status, results, truncated=False, error_code=None):
    with Session(engine) as session, session.begin():
        session.execute(update(Job).where(Job.id == job_id).values(status=status))
        session.execute(update(Attempt).where(Attempt.id == attempt_id).values(
            status=status, results=results, truncated=truncated, error_code=error_code,
            finished_at=datetime.now(timezone.utc)))


def process_queue(engine, source, settings: Settings, master_source=None) -> dict:
    processed = failed = 0
    attempt_ids = []
    with exclusive_connection(engine) as lock:
        if lock is None:
            return {"status": "busy", "message": "Another worker is running", "data": {}}
        if lock is not None:
            # Validate/load the complete master snapshot before charging any daily attempts.
            master = load_master_index(master_source if master_source is not None else source, settings)
            # A previous interrupted attempt remains charged to its original day.
            with Session(lock) as session, session.begin():
                session.execute(update(Job).where(Job.status == "running").values(status="interrupted"))
                session.execute(update(Attempt).where(Attempt.status == "running").values(
                    status="interrupted", error_code="PROCESS_INTERRUPTED", finished_at=datetime.now(timezone.utc)))
            while claimed := claim_job(lock, settings):
                job_id, name, attempt_id = claimed
                attempt_ids.append(attempt_id)
                try:
                    with source.connect() as connection:
                        matches, truncated = find_matches(connection, settings, name)
                    matches = [master.match(match, settings) for match in matches]
                    status = "matched" if any(match["account_ids"] for match in matches) else "no_account_match" if matches else "no_match"
                    finish_job(lock, job_id, attempt_id, status, matches, truncated)
                    logger.info("search_complete job_id=%s status=%s source_matches=%s account_matches=%s truncated=%s",
                                job_id, status, len(matches), sum(len(match["account_ids"]) for match in matches), truncated)
                except Exception as exc:
                    # Never print driver exception text: it can contain SQL or credentials.
                    failed += 1
                    finish_job(lock, job_id, attempt_id, "failed", [], error_code=type(exc).__name__)
                    logger.error("search_failed job_id=%s error_type=%s", job_id, type(exc).__name__)
                    processed += 1
                    # Stop on source failure to avoid consuming the daily allowance during an outage.
                    break
                processed += 1
    return {"status": "error" if failed else "success", "message": "Worker run finished",
            "data": {"attempted": processed, "failed": failed,
                     "output_file": export_run(engine, settings.output_root, attempt_ids)}}
