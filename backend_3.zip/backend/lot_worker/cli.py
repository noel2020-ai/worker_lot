import argparse
import json
import logging
from pathlib import Path

from .config import Settings
from .database import source_engine
from .demo import run_demo
from .diagnostics import check_databases
from .errors import error_details
from .local_store import LocalStore
from .packet_export import export_packets
from .packet_progress import packet_progress
from .packet_worker import process_packets
from .packetizing import packetize


def main():
    parser = argparse.ArgumentParser(description="Read-only SQL Server matching worker; state is stored locally")
    parser.add_argument("command", choices=["check-db", "packetize", "run", "status", "export", "demo"])
    parser.add_argument("--output", type=Path, help="Export destination (must not exist)")
    parser.add_argument("--batch-id", help="Limit matching, status, or export to a saved local batch")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    source = master = None
    stage = "load_settings"
    try:
        settings = Settings()
        stage = args.command
        if args.command == "check-db":
            source = source_engine(settings)
            if settings.master_database_url is not None:
                master = source_engine(settings, settings.master_database_url)
            result = check_databases(source, master, settings)
        else:
            store = LocalStore(settings.state_root / "demo" if args.command == "demo" else settings.state_root)
            if args.command == "packetize":
                source = source_engine(settings)
                result = packetize(store, source, settings)
            elif args.command == "run":
                # Matching only needs masterfile reads; source accounts are already local.
                master = source_engine(settings, settings.master_database_url)
                result = process_packets(store, None, settings, master_source=master, batch_id=args.batch_id)
            elif args.command == "demo":
                result = run_demo(store, settings.model_copy(update={"output_root": settings.output_root / "demo",
                    "master_schema": "local_csv", "master_table": settings.demo_master_file}))
            else:
                if args.command == "status":
                    data = packet_progress(store, settings, args.batch_id)
                else:
                    if args.output is None:
                        raise ValueError("Export requires --output")
                    data = export_packets(store, args.output, args.batch_id)
                result = {"status": "success", "message": "Local command completed", "data": data}
        print(json.dumps(result))
        return 1 if result["status"] == "error" else 0
    except Exception as exc:
        details = error_details(exc, stage)
        print(json.dumps({"status": "error", "message": details["explanation"], "data": details}))
        return 1
    finally:
        if master is not None:
            master.dispose()
        if source is not None:
            source.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
