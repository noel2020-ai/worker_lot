from pathlib import Path
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # No application database exists. Older DATABASE_URL values are ignored.
    source_database_url: SecretStr | None = None
    state_root: Path = Path("state")
    source_schema: str = "dbo"
    # Map these names to existing tables/views; no schema is provisioned by the worker.
    source_table: str = "Companies"
    source_id_column: str = "CompanyID"
    source_name_column: str = "CompanyName"
    source_address_column: str = "Address"
    source_city_column: str = "City"
    source_state_column: str = "State"
    source_province_column: str = "Province"
    source_extra_columns: list[str] = Field(default_factory=list)
    source_columns_path: Path | None = None
    source_max_rows: int = Field(default=250000, ge=1)
    packet_config_path: Path = Path("config/packets-v2.json")
    master_database_url: SecretStr | None = None
    master_schema: str = "dbo"
    master_table: str = "AccountMaster"
    master_account_id_column: str = "AccountID"
    master_address_column: str = "Address"
    master_city_column: str = "City"
    master_state_column: str = "State"
    master_province_column: str = "Province"
    master_max_rows: int = Field(default=250000, ge=1)
    address_similarity_min: float = Field(default=0.90, ge=0.80, le=1)
    account_score_min: int = Field(default=80, ge=0, le=100)
    output_root: Path = Path("output")
    input_root: Path = Path("examples")
    input_file: str = "companies.xlsx"
    input_name_column: str = "CompanyName"
    input_sheet: str = "Sheet1"
    demo_company_file: str = "dummy_companies.csv"
    demo_master_file: str = "dummy_accounts.csv"
    match_mode: Literal["exact", "contains", "starts_with"] = "contains"
    daily_limit: int = Field(default=100, ge=1, le=100000)
    max_results: int = Field(default=100, ge=1, le=10000)
    timezone: str = "Asia/Manila"
    source_timeout_seconds: int = Field(default=60, ge=1, le=3600)

    @field_validator("source_schema", "source_table", "source_id_column",
                     "source_name_column", "source_address_column", "source_city_column",
                     "source_state_column", "source_province_column", "master_schema", "master_table",
                     "master_account_id_column", "master_address_column", "master_city_column",
                     "master_state_column", "master_province_column")
    @classmethod
    def valid_source_identifier(cls, value: str) -> str:
        if not value.strip() or len(value) > 128 or any(ord(char) < 32 for char in value):
            raise ValueError("Source identifiers must contain 1-128 characters without control characters")
        return value

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value: str) -> str:
        ZoneInfo(value)
        return value

    @field_validator("source_extra_columns")
    @classmethod
    def valid_extra_columns(cls, values: list[str]) -> list[str]:
        for value in values:
            cls.valid_source_identifier(value)
        if len(set(values)) != len(values):
            raise ValueError("Additional source columns must be unique")
        return values
