import re

from sqlalchemy import create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.sql import Select, visitors

from .config import Settings


def enforce_readonly(engine):
    @event.listens_for(engine, "before_execute")
    def select_only(connection, statement, multiparams, params, execution_options):
        if not isinstance(statement, Select) or any(getattr(node, "is_dml", False) or getattr(node, "is_ddl", False)
                                                     for node in visitors.iterate(statement)):
            raise ValueError("SQL Server access is SELECT-only")

    @event.listens_for(engine, "before_cursor_execute")
    def no_raw_writes(connection, cursor, statement, parameters, context, executemany):
        # Check compiled and direct driver calls. Quoted identifiers/strings are data.
        cleaned = re.sub(r"'(?:''|[^'])*'|\[(?:\]\]|[^\]])*\]", "", statement)
        if (not re.match(r"^\s*SELECT\b", cleaned, re.I) or ";" in cleaned
                or re.search(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE|EXEC|EXECUTE|CREATE|REPLACE|GRANT|REVOKE|INTO)\b", cleaned, re.I)):
            raise ValueError("SQL Server access is SELECT-only; multiple statements are blocked")
    return engine


def source_engine(settings: Settings, database_url=None):
    configured = database_url if database_url is not None else settings.source_database_url
    if configured is None:
        raise ValueError("Set SOURCE_DATABASE_URL for read-only SQL Server access")
    url = make_url(configured.get_secret_value())
    if url.drivername != "mssql+pyodbc":
        raise ValueError("Read-only database URLs must use mssql+pyodbc")
    engine = create_engine(url, hide_parameters=True, connect_args={"timeout": settings.source_timeout_seconds})

    @event.listens_for(engine, "connect")
    def query_timeout(dbapi_connection, connection_record):
        dbapi_connection.timeout = settings.source_timeout_seconds

    return enforce_readonly(engine)
