"""Conservative, explainable location comparison; scores are not probabilities."""
import re
import unicodedata
from difflib import SequenceMatcher

from .config import Settings
from .matching import valid_address

FIELDS = ("address", "city", "state", "province")
ABBREVIATIONS = {"st": "street", "rd": "road", "ave": "avenue", "blvd": "boulevard",
                 "ln": "lane", "dr": "drive", "ste": "suite", "apt": "apartment"}
SCORING_VERSION = "location-v1"


def normalize_location(value: object, address: bool = False) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    # Preserve hyphens, slashes, and hashes in addresses: 12-14 is not 12/14.
    text = re.sub(r"[^\w\s/#-]" if address else r"[^\w\s]", " ", text)
    words = text.split()
    if address:
        words = [ABBREVIATIONS.get(word, word) for word in words]
    return " ".join(words)


def normalized_fields(record: dict) -> dict[str, str]:
    return {field: normalize_location(record.get(field), address=field == "address") for field in FIELDS}


def address_identifiers(address: str) -> tuple:
    numbers = tuple(re.findall(r"\b\w*\d\w*(?:[-/]\w+)*\b", address))
    units = tuple(re.findall(r"(?:\b(?:suite|apartment|unit|floor|building)\s+|#\s*)(\w+)", address))
    return numbers, units


def compare_location(source: dict, master: dict, settings: Settings) -> dict | None:
    if not valid_address(source.get("address")) or not valid_address(master.get("address")):
        return None
    left, right = normalized_fields(source), normalized_fields(master)
    if not left["address"] or not right["address"]:
        return None
    # A city is required to keep approximate street matching geographically bounded.
    if not left["city"] or left["city"] != right["city"]:
        return None
    if any(left[field] and right[field] and left[field] != right[field] for field in ("state", "province")):
        return None
    exact = left["address"] == right["address"]
    if not exact and address_identifiers(left["address"]) != address_identifiers(right["address"]):
        return None
    similarity = 1.0 if exact else SequenceMatcher(None, left["address"], right["address"], autojunk=False).ratio()
    if similarity < settings.address_similarity_min:
        return None
    matched = [field for field in FIELDS if left[field] and left[field] == right[field]]
    missing = [field for field in FIELDS if not left[field] or not right[field]]
    score = round(70 * similarity + 10 * sum(field in matched for field in ("city", "state", "province")))
    if not exact:
        score = min(score, 94)
    if score < settings.account_score_min:
        return None
    return {"scoring_version": SCORING_VERSION, "score_type": "rule_based_not_probability",
            "thresholds": {"address_similarity_min": settings.address_similarity_min,
                           "account_score_min": settings.account_score_min},
            "confidence_score": score,
            "confidence_level": "high" if score == 100 else "medium" if score >= 85 else "low",
            "address_method": "normalized_exact" if exact else "similarity",
            "address_similarity": round(similarity, 4), "matched_fields": matched,
            "missing_fields": missing, "master_location": {field: master[field] for field in FIELDS}}
