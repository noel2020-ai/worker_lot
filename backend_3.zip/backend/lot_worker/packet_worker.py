import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from .errors import error_details
from .local_store import utc_now
from .masterfile import load_master_index
from .matching import valid_address
from .packet_config import PacketConfiguration
from .packet_export import automatic_packet_export

logger = logging.getLogger(__name__)


def local_day(settings):
    return datetime.now(ZoneInfo(settings.timezone)).date().isoformat()


def pending_tasks(store, batches):
    for batch in batches:
        if batch["status"] != "ready":
            continue
        tasks = store.progress(batch["id"])
        packets = {packet.id: packet for packet in PacketConfiguration.model_validate(batch["configuration"]).packets}
        logger.info("Scanning saved accounts batch_id=%s rows=%s", batch["id"], batch["row_count"])
        for account in store.accounts(batch):
            if account["sequence"] % 10000 == 0:
                logger.info("Saved account scan batch_id=%s rows_scanned=%s", batch["id"], account["sequence"])
            for packet_id in account["segregation"]["packet_ids"]:
                key = f"{account['sequence']}-{packet_id}"
                if key not in tasks:
                    yield batch, tasks, key, account["source"], packets[packet_id]


def match_one(master, record, packet, settings):
    if packet.matching.fields["address"].required and not valid_address(record.get("address")):
        return "excluded_address", {"account_ids": [], "account_matches": [],
                                    "no_match_reason": "blank_or_po_box_address", "review_required": True}
    source = {key: value for key, value in record.items() if key != "source_data"}
    result = master.match(source, settings, rules=packet.matching)
    result["packet_id"] = packet.id
    result["master_source"] = {"schema": (packet.master.schema_name if packet.master else None) or settings.master_schema,
                               "table": (packet.master.table if packet.master else None) or settings.master_table,
                               "account_id_column": settings.master_account_id_column,
                               "scope": packet.master.model_dump() if packet.master else None}
    return ("matched" if result["account_ids"] else "no_account_match"), result


def process_packets(store, source, settings, master_source=None, batch_id=None, master_index=None):
    logger.info("Matching run started; checking local state and daily allowance")
    attempts, errors = [], []
    with store.exclusive() as acquired:
        if not acquired:
            return {"status": "busy", "message": "Another local worker is running", "data": {}}
        store.recover()
        batches = store.batches(batch_id)
        if batch_id and batches[0]["status"] != "ready":
            raise ValueError("Requested batch is not ready")
        missing_scopes = [{"batch_id": batch["id"], "packet_id": packet.id}
                          for batch in batches if batch["status"] == "ready"
                          for packet in PacketConfiguration.model_validate(batch["configuration"]).packets
                          if packet.enabled and packet.master is None and not packet.matching.fields["address"].required]
        if missing_scopes:
            return {"status": "error", "message": "Location matching requires a masterfile scope for each packet",
                    "data": {"category": "missing_packet_master", "packets": missing_scopes,
                             "action": "Configure each packet master table/view or filter, then create a new batch. No matching attempts were charged."}}
        day = local_day(settings)
        used = store.daily_used(day)
        logger.info("Daily matching allowance used=%s limit=%s", used, settings.daily_limit)
        master = master_index
        master_key = None
        for batch, tasks, key, record, packet in pending_tasks(store, batches):
            today = local_day(settings)
            if today != day:
                day, used = today, store.daily_used(today)
            if used >= settings.daily_limit:
                logger.info("Daily matching limit reached")
                break
            scope_key = (packet.master.model_dump_json() if packet.master else None,
                         not packet.matching.fields["address"].required)
            if isinstance(master_index, dict):
                master = master_index[packet.id]
            elif master_index is None and (master is None or master_key != scope_key):
                master = None  # Release the previous packet index before loading another.
                master = load_master_index(master_source if master_source is not None else source, settings,
                                           scope=packet.master, allow_invalid_address=scope_key[1])
                master_key = scope_key
            today = local_day(settings)
            if today != day:
                day, used = today, store.daily_used(today)
            if used >= settings.daily_limit:
                break
            # Persist the claim before work. A crash never refunds the charged attempt.
            tasks[key] = {"packet_id": packet.id, "status": "running", "run_date": day,
                          "started_at": utc_now(), "finished_at": None, "error_code": None, "has_result": False}
            store.save_progress(batch["id"], tasks)
            used += 1
            attempts.append(f"{batch['id']}:{key}")
            try:
                status, result = match_one(master, record, packet, settings)
                store.finish(batch["id"], key, tasks, status, result)
                logger.info("packet_match_complete batch_id=%s task=%s status=%s", batch["id"], key, status)
            except Exception as exc:
                errors.append(error_details(exc, "packet_matching_or_local_save"))
                store.finish(batch["id"], key, tasks, "failed", error_code=type(exc).__name__)
                break
    logger.info("Writing local result export attempted=%s", len(attempts))
    output = automatic_packet_export(store, settings.output_root, batch_id, attempts)
    return {"status": "error" if errors else "success", "message": "Packet matching run finished",
            "data": {"attempted": len(attempts), "failed": len(errors), "output_file": output,
                     **({"errors": errors} if errors else {})}}
