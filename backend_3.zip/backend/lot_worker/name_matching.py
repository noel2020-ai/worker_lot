"""Explainable alias matching; no external service or learned probabilities."""
import re
import unicodedata
from difflib import SequenceMatcher


def tokens(value: str, preserve_digits: bool = False) -> list[str]:
    expression = r"[^\W_]+" if preserve_digits else r"[^\W\d_]+"
    return re.findall(expression, unicodedata.normalize("NFKC", value).casefold())


def smart_match(name, pattern):
    preserve_digits = any(char.isdigit() for char in pattern.value)
    alias = " ".join(tokens(pattern.value, preserve_digits))
    words = tokens(name, preserve_digits)
    if not alias or not words:
        return None
    size = len(alias.split())
    candidates = [" ".join(words[i:i + size]) for i in range(len(words) - size + 1)]
    if alias in candidates:
        score, method = 100, "normalized_alias"
    elif len(alias) >= 4 and any(word.endswith(alias) for word in words):
        score, method = 96, "embedded_alias"
    elif len(alias) >= 5:
        score = round(100 * max((SequenceMatcher(None, alias, candidate, autojunk=False).ratio()
                                for candidate in candidates), default=0))
        method = "fuzzy_alias"
    else:
        return None
    if score < pattern.threshold:
        return None
    return {"alias": pattern.value, "method": method, "confidence_score": score,
            "score_type": "rule_based_not_probability",
            "review_required": score < pattern.review_below or method == "fuzzy_alias"}
