import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

LocationField = Literal["address", "city", "state", "province"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class NamePattern(StrictModel):
    mode: Literal["contains", "exact", "starts_with", "smart"] = "contains"
    value: str = Field(min_length=1, max_length=500)
    threshold: int = Field(default=82, ge=75, le=100)
    review_below: int = Field(default=95, ge=0, le=100)

    @field_validator("value")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Name patterns cannot be blank")
        return value.strip()


class FieldRule(StrictModel):
    mode: Literal["exact", "similarity", "ignore"] = "exact"
    required: bool = True
    weight: int = Field(default=25, ge=0, le=100)


class MatchingRules(StrictModel):
    fields: dict[LocationField, FieldRule] = Field(default_factory=lambda: {
        "address": FieldRule(mode="similarity", weight=70),
        "city": FieldRule(weight=10),
        "state": FieldRule(required=False, weight=10),
        "province": FieldRule(required=False, weight=10),
    })
    address_similarity_min: float = Field(default=0.90, ge=0.80, le=1)
    minimum_score: int = Field(default=80, ge=0, le=100)

    @model_validator(mode="after")
    def valid_rules(self):
        if set(self.fields) != {"address", "city", "state", "province"}:
            raise ValueError("Specify rules for all four location fields")
        for name, rule in self.fields.items():
            if rule.mode == "similarity" and name != "address":
                raise ValueError("Only address supports similarity matching")
            if rule.mode == "ignore" and (rule.weight != 0 or rule.required):
                raise ValueError("Ignored fields require weight=0 and required=false")
        if sum(rule.weight for rule in self.fields.values()) != 100:
            raise ValueError("Field weights must add up to 100")
        if not any(rule.required and rule.mode == "exact" for rule in self.fields.values()):
            raise ValueError("At least one exact field must be required to bound masterfile candidates")
        return self


class MasterScope(StrictModel):
    schema_name: str | None = None
    table: str | None = None
    filter_column: str | None = None
    filter_value: str | None = None

    @model_validator(mode="after")
    def valid_scope(self):
        from .config import Settings
        for value in (self.schema_name, self.table, self.filter_column):
            if value is not None:
                Settings.valid_source_identifier(value)
        if (self.filter_column is None) != (self.filter_value is None):
            raise ValueError("Master filter requires both column and value")
        if self.table is None and self.filter_column is None:
            raise ValueError("Packet master requires a table or packet filter")
        return self


class PacketDefinition(StrictModel):
    id: str = Field(pattern=r"^[a-z0-9][a-z0-9_-]{0,63}$")
    name: str = Field(min_length=1, max_length=200)
    enabled: bool = True
    priority: int = 100
    include: list[NamePattern] = Field(min_length=1)
    exclude: list[NamePattern] = Field(default_factory=list)
    matching: MatchingRules = Field(default_factory=MatchingRules)
    master: MasterScope | None = None

    @field_validator("name")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Packet name cannot be blank")
        return value.strip()


class PacketConfiguration(StrictModel):
    version: Literal[1, 2] = 1
    overlap_policy: Literal["review", "priority", "all"] = "all"
    packets: list[PacketDefinition] = Field(min_length=1)

    @model_validator(mode="after")
    def unique_packets(self):
        if self.version == 2 and any(packet.enabled and packet.master is None for packet in self.packets):
            raise ValueError("Version 2 requires a master scope for every enabled packet")
        if len({packet.id for packet in self.packets}) != len(self.packets):
            raise ValueError("Packet IDs must be unique")
        if len({packet.name.casefold() for packet in self.packets}) != len(self.packets):
            raise ValueError("Packet names must be unique")
        if not any(packet.enabled for packet in self.packets):
            raise ValueError("At least one packet must be enabled")
        return self


def load_packet_configuration(path: Path) -> PacketConfiguration:
    resolved = path.resolve(strict=True)
    if not resolved.is_file() or resolved.suffix.lower() != ".json":
        raise ValueError("PACKET_CONFIG_PATH must be a JSON file")
    return PacketConfiguration.model_validate(json.loads(resolved.read_text(encoding="utf-8")))
