from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo


def packet_progress(store, settings, batch_id=None):
    day = datetime.now(ZoneInfo(settings.timezone)).date().isoformat()
    used = store.daily_used(day)
    batches = []
    for batch in store.batches(batch_id):
        tasks = store.progress(batch["id"])
        packets = {}
        for definition in batch["configuration"]["packets"]:
            if not definition["enabled"]:
                continue
            packet_id = definition["id"]
            total = batch["packet_counts"].get(packet_id, 0)
            counts = Counter(task["status"] for task in tasks.values() if task["packet_id"] == packet_id)
            counts["pending"] = total - sum(counts.values())
            finished = total - counts["pending"] - counts["running"]
            packets[packet_id] = {"name": definition["name"], "counts": dict(counts), "total": total,
                                  "finished": finished, "progress_percent": round(100 * finished / total, 1) if total else 0}
        batches.append({"batch_id": batch["id"], "stage": batch["status"], "source_accounts": batch["row_count"],
                        "routing": batch["routing"], "packets": packets, "error_code": batch["error_code"]})
    return {"storage": "local_json", "state_root": str(store.root), "day": day,
            "daily_limit": settings.daily_limit, "attempted_today": used,
            "remaining_today": max(0, settings.daily_limit - used), "batches": batches}
