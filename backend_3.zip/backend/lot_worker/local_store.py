"""Local JSON persistence. A process lock protects claims and calendar-day limits."""
import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID, uuid4


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as output:
            temporary = Path(output.name)
            json.dump(payload, output, ensure_ascii=False, allow_nan=False)
            output.flush()
            os.fsync(output.fileno())
        for attempt in range(5):
            try:
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 4:
                    raise
                # A status reader can briefly hold the old file open on Windows.
                time.sleep(0.02)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


class LocalStore:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def batch_path(self, batch_id: str) -> Path:
        if str(UUID(batch_id)) != batch_id:
            raise ValueError("Invalid batch ID")
        path = (self.root / "batches" / batch_id).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Batch path escapes STATE_ROOT")
        return path

    @contextmanager
    def exclusive(self):
        with (self.root / "worker.lock").open("a+b") as handle:
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                yield False
                return
            try:
                yield True
            finally:
                handle.seek(0)
                if os.name == "nt":
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def create_batch(self, configuration: dict, mapping: dict) -> dict:
        batch_id = str(uuid4())
        path = self.batch_path(batch_id)
        path.mkdir(parents=True)
        batch = {"format_version": 1, "id": batch_id, "status": "building", "configuration": configuration,
                 "source_mapping": mapping, "row_count": 0, "routing": {}, "packet_counts": {},
                 "created_at": utc_now(), "error_code": None}
        atomic_json(path / "progress.json", {"format_version": 1, "tasks": {}})
        self.save_batch(batch)
        return batch

    def save_batch(self, batch: dict):
        atomic_json(self.batch_path(batch["id"]) / "batch.json", batch)

    def batches(self, batch_id=None) -> list[dict]:
        paths = ([self.batch_path(batch_id) / "batch.json"] if batch_id else
                 sorted((self.root / "batches").glob("*/batch.json")))
        batches = []
        for path in paths:
            batch = json.loads(path.read_text(encoding="utf-8"))
            if batch.get("format_version") != 1 or self.batch_path(batch["id"]) != path.parent.resolve():
                raise ValueError("Unrecognized or inconsistent local batch state")
            batches.append(batch)
        return sorted(batches, key=lambda batch: (batch["created_at"], batch["id"]))

    def progress(self, batch_id) -> dict:
        # Missing/corrupt progress must fail closed rather than reset the daily allowance.
        payload = json.loads((self.batch_path(batch_id) / "progress.json").read_text(encoding="utf-8"))
        if payload.get("format_version") != 1 or not isinstance(payload.get("tasks"), dict):
            raise ValueError("Unrecognized local progress state")
        return payload["tasks"]

    def save_progress(self, batch_id, tasks):
        atomic_json(self.batch_path(batch_id) / "progress.json", {"format_version": 1, "tasks": tasks})

    def accounts(self, batch):
        if batch["row_count"] == 0:
            return
        with (self.batch_path(batch["id"]) / "accounts.jsonl").open(encoding="utf-8") as source:
            for sequence in range(1, batch["row_count"] + 1):
                row = json.loads(source.readline())
                if row["sequence"] != sequence:
                    raise ValueError("Corrupt local account snapshot")
                yield row

    def result_path(self, batch_id, key):
        if not re.fullmatch(r"[1-9][0-9]*-[a-z0-9][a-z0-9_-]{0,63}", key):
            raise ValueError("Invalid local task key")
        return self.batch_path(batch_id) / "results" / f"{key}.json"

    def task_result(self, batch_id, key, task):
        if not task.get("has_result"):
            return None
        return json.loads(self.result_path(batch_id, key).read_text(encoding="utf-8"))

    def finish(self, batch_id, key, tasks, status, result=None, error_code=None):
        if result is not None:
            atomic_json(self.result_path(batch_id, key), result)
        tasks[key].update(status=status, finished_at=utc_now(), error_code=error_code, has_result=result is not None)
        self.save_progress(batch_id, tasks)

    def daily_used(self, day: str) -> int:
        return sum(task.get("run_date") == day for batch in self.batches()
                   for task in self.progress(batch["id"]).values())

    def recover(self):
        for batch in self.batches():
            if batch["status"] == "building":
                batch.update(status="failed", error_code="PACKETIZATION_INTERRUPTED")
                self.save_batch(batch)
            tasks = self.progress(batch["id"])
            changed = False
            for task in tasks.values():
                if task["status"] == "running":
                    task.update(status="interrupted", error_code="PROCESS_INTERRUPTED", finished_at=utc_now())
                    changed = True
            if changed:
                self.save_progress(batch["id"], tasks)
