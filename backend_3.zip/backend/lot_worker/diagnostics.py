"""Read-only checks: resolve configured tables and columns without retrieving data."""
from .errors import error_details
from .masterfile import master_statement
from .source_records import source_snapshot_statement
from .packet_config import load_packet_configuration


def check_statement(engine, stage, statement_factory):
    try:
        statement = statement_factory().order_by(None).limit(0)
        with engine.connect() as connection:
            connection.execute(statement).close()
        return {"stage": stage, "status": "success"}
    except Exception as exc:
        return {"stage": stage, "status": "error", "error": error_details(exc, stage)}


def check_databases(source, master, settings):
    checks = [check_columns(source, "source_columns", lambda: source_snapshot_statement(settings))]
    configuration = load_packet_configuration(settings.packet_config_path)
    scopes = {packet.master.model_dump_json(): packet.master for packet in configuration.packets
              if packet.enabled and packet.master is not None}
    if scopes:
        for number, scope in enumerate(scopes.values(), start=1):
            checks.append(check_columns(master if master is not None else source,
                                        f"packet_master_{number}", lambda scope=scope: master_statement(settings, scope)))
    if not scopes or any(packet.enabled and packet.master is None for packet in configuration.packets):
        checks.append(check_columns(master if master is not None else source, "master_columns", lambda: master_statement(settings)))
    failed = any(check["status"] == "error" for check in checks)
    return {"status": "error" if failed else "success",
            "message": "Database checks found errors" if failed else "Configured tables and columns are readable",
            "data": {"checks": checks, "scope": "Read-only checks of existing source and masterfile tables only"}}


def check_columns(engine, stage, statement_factory):
    check = check_statement(engine, stage, statement_factory)
    if check.get("error", {}).get("category") == "invalid_column":
        statement = statement_factory()
        failures = []
        for column in statement.selected_columns:
            probe = check_statement(engine, stage, lambda column=column: statement.with_only_columns(column))
            if probe["status"] == "error":
                # Names come from validated configuration, never from driver error text.
                failures.append({"column": getattr(getattr(column, "element", column), "name"),
                                 "error": probe["error"]})
        check["failing_columns"] = failures
    return check
