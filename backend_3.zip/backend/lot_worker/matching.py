import re

from sqlalchemy import Column, MetaData, String, Table, func, select

from .config import Settings


PO_BOX = re.compile(r"\bp[\W_]*o[\W_]*box|\bpost\s+office\s+box", re.I)


def valid_address(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip()) and not PO_BOX.search(value)


def normalize_name(value: str) -> str:
    return " ".join(value.split()).lower()


def escape_like(value: str) -> str:
    # SQL Server also treats '[' as a pattern character.
    return value.replace("~", "~~").replace("%", "~%").replace("_", "~_").replace("[", "~[")


def search_statement(settings: Settings, name: str):
    # Configuration supplies identifiers only; SQLAlchemy quotes them. No raw SQL input.
    columns = dict.fromkeys([
        settings.source_id_column, settings.source_name_column, settings.source_address_column,
        settings.source_city_column, settings.source_state_column, settings.source_province_column
    ])
    table = Table(settings.source_table, MetaData(),
                  *(Column(column, String, quote=True) for column in columns),
                  schema=settings.source_schema, quote=True, quote_schema=True)
    source_name = func.lower(func.ltrim(func.rtrim(table.c[settings.source_name_column])))
    target = name.strip().lower()
    if settings.match_mode == "exact":
        predicate = source_name == target
    else:
        pattern = escape_like(target) + "%"
        if settings.match_mode == "contains":
            pattern = "%" + pattern
        predicate = source_name.like(pattern, escape="~")
    address = table.c[settings.source_address_column]
    return select(
        table.c[settings.source_id_column].label("source_id"),
        table.c[settings.source_name_column].label("company_name"),
        address.label("address"),
        table.c[settings.source_city_column].label("city"),
        table.c[settings.source_state_column].label("state"),
        table.c[settings.source_province_column].label("province"),
    ).where(predicate, address.is_not(None), func.ltrim(func.rtrim(address)) != "").order_by(
        table.c[settings.source_id_column]
    )


def find_matches(connection, settings: Settings, name: str) -> tuple[list[dict], bool]:
    matches = []
    # Filter before applying the result cap so invalid addresses cannot hide valid hits.
    result = connection.execution_options(stream_results=True).execute(search_statement(settings, name))
    try:
        for row in result.mappings():
            if not valid_address(row["address"]):
                continue
            if len(matches) == settings.max_results:
                return matches, True
            matches.append({"source_id": str(row["source_id"]),
                            "company_name": row["company_name"], "address": row["address"].strip(),
                            **{field: str(row[field]).strip() if row[field] is not None else ""
                               for field in ("city", "state", "province")},
                            "name_match": {"method": settings.match_mode, "query": name,
                                           "purpose": "candidate_retrieval"}})
    finally:
        result.close()
    return matches, False
