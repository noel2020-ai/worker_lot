import base64
import math
import json
from datetime import date, datetime, time
from decimal import Decimal
from uuid import UUID

from sqlalchemy import Column, MetaData, Table, select
from sqlalchemy.types import NullType

from .config import Settings


def source_mapping(settings: Settings) -> dict[str, str]:
    return {"source_id": settings.source_id_column, "company_name": settings.source_name_column,
            "address": settings.source_address_column, "city": settings.source_city_column,
            "state": settings.source_state_column, "province": settings.source_province_column}


def selected_columns(settings: Settings) -> list[str]:
    if settings.source_columns_path is not None:
        path = settings.source_columns_path.resolve(strict=True)
        if path.suffix.lower() != ".json" or not path.is_file():
            raise ValueError("SOURCE_COLUMNS_PATH must be a JSON file")
        columns = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(columns, list) or not all(isinstance(column, str) for column in columns):
            raise ValueError("Source column configuration must be a JSON array of names")
        Settings.valid_extra_columns(columns)
        if settings.source_extra_columns:
            raise ValueError("Use SOURCE_COLUMNS_PATH or SOURCE_EXTRA_COLUMNS, not both")
        if not set(source_mapping(settings).values()).issubset(columns):
            raise ValueError("Source column list must include all six mapped source columns")
        return columns
    return list(dict.fromkeys([*source_mapping(settings).values(), *settings.source_extra_columns]))


def source_snapshot_statement(settings: Settings):
    table = Table(settings.source_table, MetaData(),
                  *(Column(name, NullType(), quote=True) for name in selected_columns(settings)),
                  schema=settings.source_schema, quote=True, quote_schema=True)
    # Segregation sees every source row, including invalid addresses; filtering belongs to layer 2.
    return select(*table.c).order_by(table.c[settings.source_id_column])


def json_value(value):
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite source number cannot be preserved in JSON")
        return value
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, (Decimal, UUID)):
        return str(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"encoding": "base64", "value": base64.b64encode(bytes(value)).decode("ascii")}
    raise ValueError("Unsupported source data type; expose a supported type in a SQL view")


def source_records(engine, settings: Settings):
    with engine.connect() as connection:
        result = connection.execution_options(stream_results=True).execute(source_snapshot_statement(settings))
        try:
            for count, row in enumerate(result.mappings(), start=1):
                if count > settings.source_max_rows:
                    raise ValueError("Source exceeds SOURCE_MAX_ROWS; batch will not be available for matching")
                raw = {key: json_value(value) for key, value in row.items()}
                canonical = {alias: str(row[column]).strip() if row[column] is not None else ""
                             for alias, column in source_mapping(settings).items()}
                if not canonical["source_id"] or len(canonical["source_id"]) > 500:
                    raise ValueError("Source account ID must contain 1-500 characters")
                yield {**canonical, "source_data": raw}
        finally:
            result.close()
