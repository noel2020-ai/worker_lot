"""Resumable company search worker."""
