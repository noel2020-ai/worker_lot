import unicodedata

from .packet_config import NamePattern, PacketConfiguration
from .name_matching import smart_match


def normalized_company(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def matches_pattern(name: str, pattern: NamePattern) -> bool:
    if pattern.mode == "smart":
        return smart_match(name, pattern) is not None
    value = normalized_company(pattern.value)
    if pattern.mode == "exact":
        return name == value
    if pattern.mode == "starts_with":
        return name.startswith(value)
    return value in name


def route_account(company_name: str, configuration: PacketConfiguration) -> dict:
    name = normalized_company(company_name)
    candidates = []
    for packet in sorted(configuration.packets, key=lambda item: (item.priority, item.id)):
        if not packet.enabled or any(matches_pattern(name, pattern) for pattern in packet.exclude):
            continue
        rules = [pattern.model_dump() for pattern in packet.include if matches_pattern(name, pattern)]
        if rules:
            evidence = [smart_match(name, pattern) if pattern.mode == "smart" else
                        {"alias": pattern.value, "method": pattern.mode, "confidence_score": 100,
                         "score_type": "rule_based_not_probability", "review_required": False}
                        for pattern in packet.include if matches_pattern(name, pattern)]
            best = max(evidence, key=lambda item: item["confidence_score"])
            candidates.append({"packet_id": packet.id, "packet_name": packet.name, "matched_rules": rules,
                               "name_evidence": evidence, "confidence_score": best["confidence_score"],
                               "review_required": best["review_required"]})
    selected = candidates
    status = "assigned" if candidates else "unassigned"
    if len(candidates) > 1:
        if configuration.overlap_policy == "review":
            selected, status = [], "ambiguous"
        elif configuration.overlap_policy == "priority":
            selected = candidates[:1]
    return {"status": status, "overlap_policy": configuration.overlap_policy,
            "candidate_packets": candidates, "packet_ids": [item["packet_id"] for item in selected]}
