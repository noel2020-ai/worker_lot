from pathlib import Path

from lot_worker.packet_config import load_packet_configuration
from lot_worker.packet_routing import route_account
from lot_worker.packetizing import packetize
from lot_worker.packet_worker import process_packets

CONFIG = Path(__file__).resolve().parents[2] / 'config/packets.json'


def test_production_configuration_routes_aliases_and_protects_short_codes():
    config = load_packet_configuration(CONFIG)
    assert len(config.packets) == 266
    assert 'amazon' in route_account('123AMZN', config)['packet_ids']
    assert {'amazon', 'aws'} <= set(route_account('AWS AMZN', config)['packet_ids'])
    assert '5c' in route_account('5C Data Center', config)['packet_ids']
    assert '5c' not in route_account('C Data Center', config)['packet_ids']
    assert 't5' not in route_account('T4 Data Center', config)['packet_ids']
    assert 'camp' not in route_account('campus', config)['packet_ids']
    assert 'isd' not in route_account('misdirected', config)['packet_ids']


def test_unscoped_location_run_stops_without_charging_quota(packet_environment):
    _, settings, store = packet_environment
    settings.packet_config_path = CONFIG
    record = dict(source_id='1', company_name='123AMZN', address='', city='Town',
                  state='Region', province='Province', source_data={})
    result = packetize(store, None, settings, records=iter([record]))
    assert result['status'] == 'success'
    batch_id = result['data']['batch_id']
    result = process_packets(store, None, settings, batch_id=batch_id)
    assert result['data']['category'] == 'missing_packet_master'
    assert not store.progress(batch_id)
