from copy import deepcopy

import pytest
from sqlalchemy import Column, MetaData, String, Table, create_engine

from lot_worker.config import Settings
from lot_worker.locations import compare_location
from lot_worker.masterfile import MasterIndex, load_master_index


@pytest.fixture
def settings():
    return Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                    source_database_url="mssql+pyodbc://unused/unused")


@pytest.fixture
def location():
    return {"address": "100 Example Street", "city": "Sample City", "state": "Example State", "province": "Example Province"}


def test_full_normalized_match_is_high(settings, location):
    master = {**location, "address": "100 EXAMPLE St.", "city": " sample CITY "}
    result = compare_location(location, master, settings)
    assert result["confidence_score"] == 100
    assert result["confidence_level"] == "high"
    assert result["score_type"] == "rule_based_not_probability"


@pytest.mark.parametrize("field,value", [("city", "Other City"), ("state", "Other State"),
                                        ("province", "Other Province"), ("address", "101 Example Street"),
                                        ("address", "100 Example Street Unit 2"), ("address", "PO Box 100"),
                                        ("address", ""), ("city", "")])
def test_conflicting_or_insufficient_location_rejected(settings, location, field, value):
    assert compare_location(location, {**location, field: value}, settings) is None


def test_letter_unit_conflict_rejected(settings, location):
    assert compare_location({**location, "address": "100 Example Street Unit A"},
                            {**location, "address": "100 Example Street Unit B"}, settings) is None


def test_near_address_match_requires_review(settings, location):
    result = compare_location(location, {**location, "address": "100 Exampl Street"}, settings)
    assert result is not None
    assert result["confidence_level"] == "medium"
    assert result["confidence_score"] <= 94
    assert result["address_method"] == "similarity"


def test_missing_fields_are_not_treated_as_agreement(settings, location):
    result = compare_location(location, {**location, "state": "", "province": ""}, settings)
    assert result["confidence_score"] == 80
    assert result["confidence_level"] == "low"
    assert result["missing_fields"] == ["state", "province"]
    settings.account_score_min = 90
    assert compare_location(location, {**location, "state": "", "province": ""}, settings) is None


def test_multiple_accounts_and_repeated_rows_preserve_ids(settings, location):
    first = {**location, "account_id": "0001"}
    second = {**location, "account_id": "0002"}
    index = MasterIndex([first, deepcopy(first), second])
    result = index.match(location, settings)
    assert result["account_ids"] == ["0001", "0002"]
    assert result["multiple_accounts"] and result["review_required"]
    assert len(result["account_matches"][0]["evidence"]) == 1


def test_master_mapping_and_cap(settings):
    settings.master_schema = "main"
    settings.master_table = "Account Master"
    settings.master_account_id_column = "Account Code"
    settings.master_address_column = "Street"
    settings.master_city_column = "Town"
    settings.master_state_column = "Region"
    settings.master_province_column = "Province Name"
    settings.master_max_rows = 1
    engine = create_engine("sqlite://")
    table = Table("Account Master", MetaData(), *(Column(name, String) for name in
                  ("Account Code", "Street", "Town", "Region", "Province Name")))
    table.metadata.create_all(engine)
    row = {"Account Code": "0001", "Street": "1 Test Road", "Town": "Test City", "Region": "", "Province Name": ""}
    with engine.begin() as connection:
        connection.execute(table.insert(), [row])
    index = load_master_index(engine, settings)
    assert index.by_city["test city"][0]["account_id"] == "0001"
    with engine.begin() as connection:
        connection.execute(table.insert(), [{**row, "Account Code": "0002"}])
    with pytest.raises(ValueError, match="MASTER_MAX_ROWS"):
        load_master_index(engine, settings)
    engine.dispose()
