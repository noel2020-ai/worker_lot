import json

import pytest
from sqlalchemy import MetaData, Table, Column, String, text, select, event, literal_column
from sqlalchemy.exc import ProgrammingError
from sqlalchemy.sql import Select

from lot_worker.diagnostics import check_databases, check_columns
from lot_worker.errors import error_details
from lot_worker.source_records import source_snapshot_statement


@pytest.mark.parametrize("sql", ["CREATE TABLE bad (id int)", "UPDATE lot_demo_companies SET City='x'",
                                "DELETE FROM lot_demo_companies", "DROP TABLE lot_demo_companies",
                                "SELECT 1; DELETE FROM lot_demo_companies", "SELECT * INTO bad FROM lot_demo_companies",
                                "EXEC sp_getapplock 'x'"])
def test_direct_driver_writes_blocked(packet_environment, sql):
    engine, _, _ = packet_environment
    with engine.connect() as connection, pytest.raises(ValueError, match="SELECT-only"):
        connection.exec_driver_sql(sql)


def test_structured_dml_ddl_and_raw_text_blocked(packet_environment):
    engine, _, _ = packet_environment
    table = Table("bad", MetaData(), Column("value", String))
    with engine.connect() as connection:
        for statement in (table.insert().values(value="x"), table.update().values(value="x"), table.delete(), text("SELECT 1")):
            with pytest.raises(ValueError, match="SELECT-only"):
                connection.execute(statement)
        with pytest.raises(ValueError, match="SELECT-only"):
            table.create(connection, checkfirst=False)
        with pytest.raises(ValueError, match="SELECT-only"):
            connection.execute(select(table).add_cte(table.delete().cte("bad_delete")))
        with pytest.raises(ValueError, match="SELECT-only"):
            connection.execute(select(literal_column("1; DELETE FROM lot_demo_companies")))


def test_check_db_checks_only_source_and_master(packet_environment):
    engine, settings, _ = packet_environment
    seen = []

    @event.listens_for(engine, "before_execute")
    def capture(connection, statement, multiparams, params, execution_options):
        assert isinstance(statement, Select)
        assert statement._limit_clause.value == 0
        seen.append(statement)

    response = check_databases(engine, None, settings)
    assert response["status"] == "success"
    assert [check["stage"] for check in response["data"]["checks"]] == ["source_columns", "master_columns"]
    assert len(seen) == 2


@pytest.mark.parametrize("code,category", [(207, "invalid_column"), (208, "missing_table"), (229, "permission_denied")])
def test_error_details_never_expose_secrets(code, category):
    error = ProgrammingError("PRIVATE_SQL", {"password": "SECRET"}, Exception("42000", f"Password=SECRET ({code})"))
    details = error_details(error, "packetize")
    assert details["category"] == category and details["native_code"] == code
    assert "SECRET" not in json.dumps(details) and "PRIVATE" not in json.dumps(details)
    assert "init-db" not in details["action"]


def test_identifies_bad_source_column(packet_environment):
    engine, settings, _ = packet_environment
    settings.source_columns_path = None
    settings.source_extra_columns = ["MissingColumn"]

    @event.listens_for(engine, "before_execute")
    def fake_error(connection, statement, multiparams, params, execution_options):
        if "MissingColumn" in statement.selected_columns.keys():
            raise ProgrammingError("private SQL", {}, Exception("42S22", "Invalid column (207)"))

    result = check_columns(engine, "source_columns", lambda: source_snapshot_statement(settings))
    assert [column["column"] for column in result["failing_columns"]] == ["MissingColumn"]
