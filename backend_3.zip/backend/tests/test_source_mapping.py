import pytest
from pydantic import ValidationError
from sqlalchemy import Column, Integer, MetaData, String, Table, create_engine

from lot_worker.config import Settings
from lot_worker.matching import find_matches


def configured(**overrides):
    return Settings(_env_file=None, database_url="mssql+pyodbc://unused/unused",
                    source_database_url="mssql+pyodbc://unused/unused", **overrides)


def test_production_mapping_uses_selected_columns_and_stable_output():
    settings = configured(source_schema="main", source_table="Production Companies",
                          source_id_column="MasterID", source_name_column="Legal Company Name",
                          source_address_column="Street Address", source_city_column="Town",
                          source_state_column="Region", source_province_column="County")
    engine = create_engine("sqlite://")
    table = Table("Production Companies", MetaData(), Column("MasterID", Integer),
                  Column("Legal Company Name", String), Column("Street Address", String),
                  Column("Address", String), Column("Town", String), Column("Region", String), Column("County", String))
    table.metadata.create_all(engine)
    with engine.begin() as connection:
        connection.execute(table.insert(), [
            {"MasterID": 1, "Legal Company Name": "Demo Cedar", "Street Address": "10 Test Street", "Address": "PO Box 1"},
            {"MasterID": 2, "Legal Company Name": "Demo Cedar", "Street Address": "PO Box 2", "Address": "20 Test Street"},
            {"MasterID": 3, "Legal Company Name": "Demo Cedar", "Street Address": "  ", "Address": "30 Test Street"},
        ])
        matches, truncated = find_matches(connection, settings, "Cedar")
    assert len(matches) == 1
    assert {key: matches[0][key] for key in ("source_id", "company_name", "address")} == {
        "source_id": "1", "company_name": "Demo Cedar", "address": "10 Test Street"}
    assert matches[0]["city"] == ""
    assert truncated is False
    engine.dispose()


@pytest.mark.parametrize("value", ["", "   ", "x" * 129, "Name\nColumn"])
def test_invalid_source_identifier_is_rejected(value):
    with pytest.raises(ValidationError):
        configured(source_name_column=value)
