import json

import pytest

from lot_worker import cli


def test_local_status_and_demo_do_not_construct_sql_engine(packet_environment, monkeypatch, capsys):
    _, settings, _ = packet_environment
    monkeypatch.setattr(cli, "Settings", lambda: settings)

    def forbidden(*args, **kwargs):
        pytest.fail("Local command attempted to connect to SQL Server")

    monkeypatch.setattr(cli, "source_engine", forbidden)
    monkeypatch.setattr("sys.argv", ["lot-worker", "status"])
    assert cli.main() == 0
    assert json.loads(capsys.readouterr().out)["data"]["batches"] == []
    monkeypatch.setattr("sys.argv", ["lot-worker", "demo"])
    assert cli.main() == 0
    response = json.loads(capsys.readouterr().out)
    assert response["data"]["attempted"] == 23
    assert (settings.state_root / "demo" / "batches").exists()
    monkeypatch.setattr("sys.argv", ["lot-worker", "status"])
    assert cli.main() == 0
    assert json.loads(capsys.readouterr().out)["data"]["attempted_today"] == 0


@pytest.mark.parametrize("command", ["init-db", "seed-demo", "run-legacy", "ingest"])
def test_removed_write_commands_rejected(command, monkeypatch):
    monkeypatch.setattr("sys.argv", ["lot-worker", command])
    with pytest.raises(SystemExit) as exc:
        cli.main()
    assert exc.value.code == 2
