from pathlib import Path

import pytest
from pydantic import ValidationError
from sqlalchemy.dialects import mssql

from lot_worker.demo import run_demo
from lot_worker.masterfile import master_statement
from lot_worker.packet_config import MasterScope, PacketConfiguration, load_packet_configuration
from lot_worker.packet_config import NamePattern
from lot_worker.name_matching import smart_match
from lot_worker.packet_locations import compare_packet_location
from lot_worker.packet_routing import route_account
from lot_worker.packetizing import packetize
from lot_worker.packet_worker import process_packets
from lot_worker.packet_export import packet_export_payload

CONFIG = Path(__file__).resolve().parents[2] / 'config/packets-v2.json'


@pytest.mark.parametrize('alias,positive,negative', [
    ('5c', '5C Data Center', 'C Data Center'),
    ('t5', 'T5-Data Center', 'T4 Data Center'),
    ('5c', 'TX-5C', '15C Data Center'),
])
def test_numeric_aliases_preserve_digits(alias, positive, negative):
    pattern = NamePattern(mode='smart', value=alias, threshold=100)
    assert smart_match(positive, pattern) is not None
    assert smart_match(negative, pattern) is None


@pytest.mark.parametrize('name,method', [('123amzn', 'normalized_alias'),
    ('TX-001Amzn', 'normalized_alias'), ('AWSAmzn', 'embedded_alias'),
    ('Amazon-BLDG1', 'normalized_alias'), ('Amazom', 'fuzzy_alias')])
def test_smart_alias_evidence(name, method):
    result = route_account(name, load_packet_configuration(CONFIG))
    assert result['packet_ids'] == ['amazon']
    candidate = result['candidate_packets'][0]
    assert method in [item['method'] for item in candidate['name_evidence']]
    assert candidate['review_required'] == (method == 'fuzzy_alias')


def test_short_alias_not_fuzzed_and_threshold_is_configurable():
    config = load_packet_configuration(CONFIG)
    assert 'amazon' not in route_account('AMZ', config)['packet_ids']
    for pattern in config.packets[0].include:
        pattern.threshold = 95
    assert 'amazon' not in route_account('Amazom', config)['packet_ids']
    assert route_account('123AMZN Cedar', config)['packet_ids'] == ['amazon', 'cedar']


def test_v2_requires_scoped_master():
    config = load_packet_configuration(CONFIG).model_dump()
    config['packets'][0]['master'] = None
    with pytest.raises(ValidationError):
        PacketConfiguration.model_validate(config)


def test_ignored_and_optional_address():
    rules = load_packet_configuration(CONFIG).packets[0].matching
    source = dict(address='', city='Town', state='Region', province='Province')
    master = {**source, 'address': 'PO Box 12'}
    assert compare_packet_location(source, master, rules) is not None
    assert compare_packet_location(source, {**master, 'city': 'Elsewhere'}, rules) is None
    assert compare_packet_location(source, {**master, 'state': ''}, rules) is None
    rules.fields['address'].mode = 'similarity'
    rules.fields['address'].weight = 5
    rules.fields['city'].weight = 35
    assert compare_packet_location({**source, 'address': '1 Road'},
                                   {**master, 'address': '9 Street'}, rules) is not None


def test_master_filter_uses_bound_parameter(packet_environment):
    _, settings, _ = packet_environment
    value = "packet' OR 1=1 --"
    statement = master_statement(settings, MasterScope(filter_column='PacketID', filter_value=value))
    compiled = statement.compile(dialect=mssql.dialect())
    assert value not in str(compiled)
    assert value in compiled.params.values()
    separate = master_statement(settings, MasterScope(schema_name='other', table='Scoped Master'))
    assert '[other].[Scoped Master]' in str(separate.compile(dialect=mssql.dialect()))


def test_scoped_matching_accepts_blank_addresses_without_cross_packet_ids(packet_environment):
    engine, settings, store = packet_environment
    settings.packet_config_path = CONFIG
    record = dict(source_id='test1', company_name='123AMZN', address='', city='Sample City',
                  state='Example State', province='Example Province', source_data={})
    batch_id = packetize(store, None, settings, records=iter([record]))['data']['batch_id']
    result = process_packets(store, engine, settings, batch_id=batch_id)
    assert result['status'] == 'success'
    snapshot = packet_export_payload(store, batch_id)
    packet = snapshot['batches'][0]['packets'][0]
    assert packet['account_ids'] == ['000101', '000102', 'WRONG-NUMBER']
    assert packet['accounts'][0]['status'] == 'matched'
    assert 'DEMO-001' not in packet['account_ids']


def test_v2_demo_runs_without_database(packet_environment):
    _, settings, store = packet_environment
    settings.packet_config_path = CONFIG
    result = run_demo(store, settings)
    assert result['status'] == 'success'
    assert all(task['status'] != 'excluded_address' for task in store.progress(result['data']['batch_id']).values())
