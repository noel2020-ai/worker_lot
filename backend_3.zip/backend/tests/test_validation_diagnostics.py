import json
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError

from lot_worker.config import Settings
from lot_worker.errors import error_details
from lot_worker.packet_config import PacketConfiguration
from lot_worker.packetizing import packetize


def test_packet_validation_reports_rule_before_source_or_state_access(tmp_path):
    config = {"packets": [{"id": "sample", "name": "Sample",
                           "include": [{"value": "sample"}],
                           "matching": {"fields": {}}}]}
    path = tmp_path / "packets.json"
    path.write_text(json.dumps(config), encoding="utf-8")
    store, source = MagicMock(), MagicMock()
    settings = Settings(_env_file=None, packet_config_path=path)
    result = packetize(store, source, settings)
    assert result["status"] == "error"
    assert result["data"]["stage"] == "load_packet_configuration"
    issue = result["data"]["validation_errors"][0]
    assert issue["field"] == "packets.0.matching"
    assert issue["message"] == "Specify rules for all four location fields"
    assert not store.mock_calls and not source.mock_calls


def test_validation_diagnostics_do_not_echo_values_or_unknown_keys():
    secret = "private-credential-value"
    with pytest.raises(ValidationError) as failure:
        PacketConfiguration.model_validate({"packets": [], secret: secret})
    details = error_details(failure.value, "load_packet_configuration")
    assert secret not in json.dumps(details)
    assert any(issue["field"] == "<unknown field>" for issue in details["validation_errors"])


def test_settings_diagnostic_redacts_invalid_value():
    with pytest.raises(ValidationError) as failure:
        Settings(_env_file=None, daily_limit="private-credential-value")
    details = error_details(failure.value, "load_settings")
    assert details["validation_errors"][0]["field"] == "daily_limit"
    assert "private-credential-value" not in json.dumps(details)
