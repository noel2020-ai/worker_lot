import json
import subprocess
import sys
from datetime import date, timedelta

import pytest

from lot_worker import local_store
from lot_worker.demo import run_demo
from lot_worker.local_store import LocalStore, atomic_json, utc_now
from lot_worker.packetizing import packetize
from lot_worker.packet_worker import process_packets


def test_process_lock_released_by_os(tmp_path):
    store = LocalStore(tmp_path / "state")
    script = "from pathlib import Path\nfrom lot_worker.local_store import LocalStore\nimport sys\nwith LocalStore(Path(sys.argv[1])).exclusive() as acquired:\n print(acquired)"
    with store.exclusive() as acquired:
        assert acquired
        result = subprocess.run([sys.executable, "-c", script, str(store.root)], capture_output=True, text=True, check=True)
        assert result.stdout.strip() == "False"
    result = subprocess.run([sys.executable, "-c", script, str(store.root)], capture_output=True, text=True, check=True)
    assert result.stdout.strip() == "True"


def test_atomic_write_failure_retains_previous_state(tmp_path, monkeypatch):
    path = tmp_path / "progress.json"
    atomic_json(path, {"claimed": 1})

    def fail(*args):
        raise OSError("simulated disk failure")

    monkeypatch.setattr(local_store.os, "replace", fail)
    with pytest.raises(OSError):
        atomic_json(path, {"claimed": 2})
    assert json.loads(path.read_text()) == {"claimed": 1}
    assert len(list(tmp_path.iterdir())) == 1


def test_interrupted_claim_stays_charged_and_new_day_renews_quota(packet_environment, monkeypatch):
    engine, settings, store = packet_environment
    batch_id = packetize(store, engine, settings)["data"]["batch_id"]
    first = next(store.accounts(store.batches(batch_id)[0]))
    packet_id = first["segregation"]["packet_ids"][0]
    key = f"1-{packet_id}"
    today = date.today().isoformat()
    store.save_progress(batch_id, {key: {"packet_id": packet_id, "status": "running", "run_date": today,
                                        "started_at": utc_now(), "has_result": False}})
    settings.daily_limit = 1
    monkeypatch.setattr("lot_worker.packet_worker.local_day", lambda settings: today)
    assert process_packets(store, engine, settings)["data"]["attempted"] == 0
    assert store.progress(batch_id)[key]["status"] == "interrupted"
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    monkeypatch.setattr("lot_worker.packet_worker.local_day", lambda settings: tomorrow)
    assert process_packets(store, engine, settings)["data"]["attempted"] == 1
    assert store.daily_used(today) == 1 and store.daily_used(tomorrow) == 1


def test_missing_progress_fails_closed(packet_environment):
    engine, settings, store = packet_environment
    batch_id = packetize(store, engine, settings)["data"]["batch_id"]
    (store.batch_path(batch_id) / "progress.json").unlink()
    with pytest.raises(FileNotFoundError):
        process_packets(LocalStore(settings.state_root), engine, settings)


def test_demo_never_needs_sql_server(packet_environment):
    _, settings, store = packet_environment
    result = run_demo(store, settings)
    assert result["status"] == "success" and result["data"]["attempted"] == 23
    assert store.batches()[0]["source_mapping"]["kind"] == "local_demo_csv"


def test_batch_path_traversal_rejected(tmp_path):
    store = LocalStore(tmp_path)
    with pytest.raises(ValueError):
        store.batch_path("../../outside")
