# Production packet review

Reviewed 266 packets in `packets.json`. Preserved all packet IDs, names, priorities, enabled flags, exclusions, and overlap policy `all`. The original input is saved as `packets.production-original.json`.

Changes:

- Replaced contains rules with smart alias matching and removed the duplicate case-only CDW alias.
- Added AMZN to the existing Amazon packet, as requested. AWS remains a separate packet; overlaps are preserved.
- Used threshold 100 for short aliases and broad categories, 90 for other names, and 82 for Amazon's spelling variants. Short aliases and broad categories require normalized token/phrase matches; they do not match arbitrary substrings. Review threshold is 95 and fuzzy matches always carry a review flag.
- Corrected smart matching to preserve digits in aliases such as 5C and T5.
- Set Address to ignored, with City/State/Province required and weighted 40/30/30. Missing required location values cannot match. Weights and required fields can be changed per packet once actual master coverage is known.

Masterfile assignments are intentionally unresolved. The file remains version 1 so packetization can proceed without inventing scopes. The worker rejects location matching without master scopes and charges no attempts for that rejection. Once the assignments are known, add `master` to every enabled packet and change `version` to 2. Create a new batch to capture the new mappings; saved batches retain their original configuration.

For a shared table use `"master": {"filter_column": "ActualPacketColumn", "filter_value": "ActualValue"}`. For separate tables/views use `"master": {"schema_name": "dbo", "table": "ActualPacketView"}`. These are examples only: actual identifiers and values must come from the master data owner. The worker cannot infer company scope from geography alone.

Items for human review, left unchanged:

- `martiott` may be intended to include Marriott; `texas_instrucments` may be intended to include Texas Instruments; `quicktrip` may be intended to include QuikTrip. Confirm before adding aliases or renaming anything.
- `abbot_lab`, `space_ex`, and `northrup` may represent spelling variants or deliberate source conventions.
- Broad category packets (school, district, city of, camp, base, defense, etc.) can overlap company packets. That is allowed by the requested overlap policy.
- Abbreviation and full-name packets remain separate (AWS/Amazon, MSFT/Microsoft, IBM/International Business, etc.). No business relationships were inferred or packets merged.

Run from the project root after deploying the revised backend and config:

```powershell
python -m pip install -e ./backend
# Set PACKET_CONFIG_PATH=./config/packets.json in your existing .env.
python -m lot_worker.cli packetize
```

Only after assigning masters, run `check-db`, create a new batch, and run matching with `--batch-id NEW_BATCH_ID`. Keep the daily quota and existing local state intact. Production SQL Server was not accessed for this review. Five-million-row performance was not tested.
