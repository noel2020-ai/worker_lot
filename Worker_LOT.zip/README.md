# Company search worker

Standalone Python batch worker: reads company names from Excel/CSV, searches a SQL Server table/view, rejects blank addresses and PO Box addresses, then matches address/city/state/province against a SQL Server account masterfile. It stores results in SQL Server and automatically writes a JSON file per run. No frontend or HTTP server is required.

SQL Server is the only application database. Included fictional names and addresses let you test before connecting a real company source. External web search is not implemented.

## Behavior

- `MATCH_MODE=exact`, `contains`, or `starts_with`; comparison is case insensitive. Accents follow the source database collation. This is text matching, not fuzzy entity resolution.
- Contains/starts-with treat `%`, `_`, and `[` in company names literally. Query values are bound parameters; identifiers are quoted. Arbitrary SQL is not accepted.
- Addresses must contain non-whitespace text and must not contain `PO Box`, `P.O. Box`, `P O Box`, `POBOX`, or `Post Office Box`, case insensitively. Street-address validity is not otherwise verified.
- One input company is one attempt, regardless of the number of matches. Default: at most 100 attempts per local calendar day in `TIMEZONE`. Repeated runs and failures use the same persisted allowance. This is a daily batch, not evenly spaced requests.
- A SQL Server application lock serializes runs, imports, and demo seeding using the same application database. Keep all invocations on the same database, timezone, and daily limit. Locking uses the application connection and [Microsoft's sp_getapplock](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql).
- Results include source ID, company name, address, city, state, province, and all qualifying masterfile account IDs with confidence evidence. `MAX_RESULTS` caps source candidates per input name; `truncated=true` means the output is incomplete for that name. Account matches within each retained source candidate are not capped.
- Input names are deduplicated across imports using lowercase and collapsed whitespace. The original trimmed name is searched. Completed names are not searched again automatically.
- A source error records a failed attempt and stops the batch to avoid consuming the allowance during an outage. Interrupted attempts are marked on the next run. Failed/interrupted names need manual review; automatic retry/reset is not implemented.
- `DATABASE_URL` is the writable SQL Server application connection for worker tables, demo seeding, and application locking. `SOURCE_DATABASE_URL` and optional `MASTER_DATABASE_URL` are SELECT-only connections. Masterfile reads use the source connection if no separate master URL is configured. Search/masterfile paths accept constructed SELECT queries only.

## Structure

```text
backend/
  lot_worker/       # configuration, ingestion, matching, database, queue, CLI
  tests/           # address, SQL binding, ingestion, quota tests
  pyproject.toml
scripts/
  register-daily-task.ps1
examples/
  dummy_names.csv
  dummy_companies.csv
  dummy_accounts.csv
  matching_sample.json
.env.example
```

## Setup (PowerShell, repository root)

Install SQL Server 2016 or newer and Microsoft ODBC Driver 18 for SQL Server. Create an empty test application database and an application user with default schema `dbo`, table-creation rights for initialization, and read/write rights on the worker tables. Use a separate SELECT-only source user. For the demo both connections point to the same database; grant the source user SELECT on `dbo.lot_demo_companies` and `dbo.lot_demo_accounts` after seeding. Use a trusted SQL Server certificate; the example enables TLS certificate validation.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e './backend[test]'
Copy-Item .env.example .env
```

Edit `.env` with real connection details, source mappings and input location. Sample values:

```dotenv
DATABASE_URL=mssql+pyodbc://worker:CHANGE_ME@localhost/company_worker?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes&TrustServerCertificate=no
SOURCE_DATABASE_URL=mssql+pyodbc://reader:CHANGE_ME@localhost/company_worker?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes&TrustServerCertificate=no
SOURCE_SCHEMA=dbo
SOURCE_TABLE=lot_demo_companies
SOURCE_ID_COLUMN=CompanyID
SOURCE_NAME_COLUMN=CompanyName
SOURCE_ADDRESS_COLUMN=Address
SOURCE_CITY_COLUMN=City
SOURCE_STATE_COLUMN=State
SOURCE_PROVINCE_COLUMN=Province
MASTER_SCHEMA=dbo
MASTER_TABLE=lot_demo_accounts
MASTER_ACCOUNT_ID_COLUMN=AccountID
MASTER_ADDRESS_COLUMN=Address
MASTER_CITY_COLUMN=City
MASTER_STATE_COLUMN=State
MASTER_PROVINCE_COLUMN=Province
MASTER_MAX_ROWS=250000
ADDRESS_SIMILARITY_MIN=0.90
ACCOUNT_SCORE_MIN=80
OUTPUT_ROOT=./output
INPUT_ROOT=./examples
INPUT_FILE=dummy_names.csv
DEMO_COMPANY_FILE=dummy_companies.csv
DEMO_MASTER_FILE=dummy_accounts.csv
INPUT_NAME_COLUMN=CompanyName
INPUT_SHEET=Sheet1
MATCH_MODE=contains
DAILY_LIMIT=100
MAX_RESULTS=100
TIMEZONE=Asia/Manila
SOURCE_TIMEOUT_SECONDS=60
SCHEDULE_TIME=09:00
```

Store input files beneath `INPUT_ROOT`; `INPUT_FILE` is relative to that folder. Paths escaping the root, including resolved symlinks, are rejected. Only `.csv` and `.xlsx` are supported. URL-encode password punctuation in database URLs. Keep `.env` out of source control.

The demo has 12 search names, 14 fictional source records (8 valid street addresses and 6 excluded addresses), and 13 masterfile rows. It includes `Amazon` matching `102AMAZON` and `Facebook` matching `FACEBOOK-BLDG1`. All example addresses and account IDs are invented test data, not information about those companies.

## Static source columns

The worker uses six explicitly mapped source columns. It does not auto-detect columns or use `SELECT *`. Edit this block in your `.env` to match the real SQL Server table or view; no Python edits are needed:

```dotenv
SOURCE_SCHEMA=dbo
SOURCE_TABLE=ProductionCompanies
SOURCE_ID_COLUMN=MasterID
SOURCE_NAME_COLUMN=LegalCompanyName
SOURCE_ADDRESS_COLUMN=AddressLine1
SOURCE_CITY_COLUMN=CityName
SOURCE_STATE_COLUMN=StateName
SOURCE_PROVINCE_COLUMN=ProvinceName
```

These are illustrative production names, not a required database schema.

| Setting | Dummy default | Used for |
| --- | --- | --- |
| `SOURCE_ID_COLUMN` | `CompanyID` | Source identifier returned as `source_id`; use a unique ID |
| `SOURCE_NAME_COLUMN` | `CompanyName` | Exact/contains/starts-with search; returned as `company_name` |
| `SOURCE_ADDRESS_COLUMN` | `Address` | Blank/PO Box exclusion; returned as `address` |
| `SOURCE_CITY_COLUMN` | `City` | Required city comparison; returned as `city` |
| `SOURCE_STATE_COLUMN` | `State` | State comparison; returned as `state` |
| `SOURCE_PROVINCE_COLUMN` | `Province` | Province comparison; returned as `province` |

Only the configured address column is checked. If production addresses span several fields, use a SQL Server view with one combined address column and map that column. Enter literal column names without brackets, SQL expressions, or aliases. Names containing spaces are supported, for example `SOURCE_NAME_COLUMN="Legal Company Name"`. Invalid blank or overlength identifiers are rejected before connecting; actual column existence is checked by SQL Server when the search executes.

`INPUT_NAME_COLUMN` independently specifies the company-name header in the Excel/CSV search list. It does not have to match `SOURCE_NAME_COLUMN`. The dummy seed file and table retain their fixed demo columns; changing source mappings does not rename or modify any database columns.

Changes apply on the next CLI or scheduled invocation. Existing completed jobs and results retain their history and are not automatically searched again. To verify production mappings, import a new known company name, run the worker, and export the results to compare against that source record.

## Masterfile matching and confidence

Configure the masterfile SQL Server table/view with the `MASTER_*` mappings shown above. If it is in another database, set `MASTER_DATABASE_URL` to its SELECT-only connection URL (same format as `SOURCE_DATABASE_URL`). Source and master column names may differ. Account IDs are exported as strings; store leading-zero IDs as text in SQL Server because zeros already lost from numeric storage cannot be recovered.

1. Contains matching is case insensitive and finds both requested examples, even when the query is attached to digits or a building suffix. It is candidate retrieval, not proof of corporate identity. Exact and starts-with modes remain available.
2. Every candidate supplies its address, city, state, and province. Blank and PO Box addresses are excluded.
3. The masterfile is read once per run into an index by normalized city. City must be present on both sides and agree. Conflicting nonblank state or province values reject a match. Missing fields receive no points; two blank values are not agreement.
4. Address comparison normalizes case, whitespace, punctuation, and common abbreviations (`St`, `Rd`, `Ave`, `Blvd`, `Ln`, `Dr`, `Ste`, `Apt`). It does not geocode or translate state/province names or codes. Different numeric address identifiers or explicit unit identifiers reject approximate matches. Other address differences require similarity of at least `ADDRESS_SIMILARITY_MIN` (default 0.90).
5. The score is `70 × address similarity + 10 per agreeing city/state/province`, rounded to an integer. Non-exact addresses are capped at 94. Default inclusion threshold is `ACCOUNT_SCORE_MIN=80`. High means 100 (all four normalized fields agree); medium means 85–99; low means below 85. Scores are rule-based evidence, not calibrated probabilities. Approximate matches require review.
6. Every qualifying account ID is retained. Repeated master rows for the same ID are grouped with distinct evidence. Multiple account IDs remain separate and require review even when each has a high location score. Shared addresses do not establish company ownership.

`MASTER_MAX_ROWS` bounds the in-memory snapshot; exceeding it fails before daily attempts are charged rather than returning partial masterfile matches. For larger datasets use a suitably scoped master view or raise the limit with sufficient memory. Rows with blank/PO Box addresses or missing cities are excluded and counted in logs; blank account IDs cause validation failure. All mapped columns must exist. If a region field does not exist in production, expose a nullable column in a view and map it; missing values reduce confidence.

Job status `matched` means at least one account matched, `no_account_match` means source candidates exist but no account met the rules, and `no_match` means no valid source candidate. Source candidates with zero accounts are still included in JSON with a reason. Every result includes separate name-match evidence and per-account location evidence. Older stored attempts keep their original schema and scores; changing thresholds does not reprocess them.

See [examples/matching_sample.json](examples/matching_sample.json) for a generated example from the fictional dataset: Amazon returns `000101` and `000102`, and Facebook returns `000201`.

## Run the worker

Always run from the repository root so `.env` resolves consistently.

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli seed-demo
.\.venv\Scripts\python.exe -m lot_worker.cli run
.\.venv\Scripts\python.exe -m lot_worker.cli status
.\.venv\Scripts\python.exe -m lot_worker.cli export --output results.json
```

`seed-demo` validates the configured CSVs, creates worker tables plus `lot_demo_companies` and `lot_demo_accounts` in the application database, and inserts the dummy records and input queue. It is repeatable without duplicating records or resetting completed jobs. Conflicting existing demo IDs cause an error without overwriting records. It never seeds the configured external source/master tables. Use a fresh test database for this expanded demo: existing demo tables from earlier versions are not automatically altered to add city/state/province. No application queue schema migration is needed; enriched matches use the existing JSON results field.

With a fresh queue, `MATCH_MODE=contains`, and `DAILY_LIMIT=100`, the demo produces 7 matched jobs, 5 no-match jobs, and 8 returned source company records. Exact mode needs full company names rather than the supplied partial names.

For real input, change the source mappings and file settings, then use `init-db` and `ingest` instead of `seed-demo`. `init-db` creates only worker tables in SQL Server; it does not migrate existing schemas or PostgreSQL data. `ingest` adds new names without resetting prior work. `run` processes pending names up to the remaining daily allowance. Export creates a new JSON file and refuses to overwrite an existing file. Logs include job IDs and error types, not connection strings or driver error text.

Backend run command is `python -m lot_worker.cli run` inside the installed virtual environment. Frontend run command: not applicable; this deliverable is a CLI worker. FastAPI can be added separately if an HTTP control panel is required.

Every run that finishes processing automatically writes `OUTPUT_ROOT/matches-<UTC timestamp>-<unique ID>.json` containing that run's attempts, including failures and no-matches. The command prints the path. A run with no new attempts writes an empty JSON array; a busy run or a masterfile validation failure produces no export. The scheduled task uses the same command and exports automatically. `export --output results.json` exports all historical attempts and refuses to overwrite a file. An export failure does not undo processed attempts; use the export command to recover their JSON without searching again. Restrict the output directory to appropriate users because exports contain addresses and account IDs.

## Schedule daily on Windows

```powershell
.\scripts\register-daily-task.ps1
Get-ScheduledTask -TaskName CompanySearchWorker
```

The script registers the current virtual-environment path and project working directory; it reads `SCHEDULE_TIME` from `.env`. Re-run registration after changing the schedule, removing the old task first if necessary. The script intentionally does not overwrite an existing task.

The task runs while the current Windows user is logged in. For unattended execution while logged out, configure the task in Task Scheduler with an appropriate account and “Run whether user is logged on or not.” Windows schedules against its local timezone: make it agree with `TIMEZONE`. Keep the machine available at the scheduled time; `StartWhenAvailable` enables a missed run when possible. The scheduled action processes already imported pending names; import additional files explicitly with `ingest`.

## Verification

```powershell
.\.venv\Scripts\python.exe -m pytest backend/tests -q
```

Unit tests use temporary files, SQLite for matching/queue persistence, and fake connections for SQL Server lock return codes. They do not prove live SQL Server locking or connectivity. Before enabling the schedule:

1. Configure a test source with exact/partial matches, whitespace/null addresses, PO Box variants, and valid street addresses.
2. Set `DAILY_LIMIT=2`, import at least three different companies, and run twice. Only two attempts should exist for the current local date.
3. Export results and verify excluded addresses are absent, matching modes behave as expected, and source IDs match your records.
4. Launch overlapping runs against the test SQL Server database; the second should report `busy` while the first holds its lock.
5. Verify the source account cannot write, check Task Scheduler's last-run result, and restore `DAILY_LIMIT=100`.

No Google Search API or Hoovers/D&B integration is included. The SQL Server source and spreadsheet mappings are configuration placeholders until connected to your actual data. Database connectivity, production data behavior, and task execution must be verified in your environment.
