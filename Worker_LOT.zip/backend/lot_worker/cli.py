import argparse
import json
import logging
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .config import Settings
from .database import application_engine, source_engine
from .demo import seed_demo
from .exporting import export_results
from .ingestion import ingest
from .models import Base, Job
from .worker import process_queue


def main():
    parser = argparse.ArgumentParser(description="Company search worker")
    parser.add_argument("command", choices=["init-db", "seed-demo", "ingest", "run", "status", "export"])
    parser.add_argument("--output", type=Path, help="JSON export destination (must not exist)")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    engine = source = master = None
    try:
        settings = Settings()
        engine = application_engine(settings)
        if args.command == "init-db":
            Base.metadata.create_all(engine)
            data = {"message": "Worker tables created"}
        elif args.command == "seed-demo":
            data = seed_demo(engine, settings)
        elif args.command == "ingest":
            data = {"added": ingest(engine, settings)}
        elif args.command == "run":
            source = source_engine(settings)
            if settings.master_database_url is not None:
                master = source_engine(settings, settings.master_database_url)
            result = process_queue(engine, source, settings, master_source=master)
            print(json.dumps(result))
            return 1 if result["status"] == "error" else 0
        elif args.command == "status":
            with Session(engine) as session:
                data = dict(session.execute(select(Job.status, func.count()).group_by(Job.status)).all())
        else:
            if args.output is None:
                raise ValueError("Export requires --output")
            data = {"exported": export_results(engine, args.output)}
        print(json.dumps({"status": "success", "message": "Command completed", "data": data}))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "error", "message": "Command failed; check configuration, files and database access",
                          "data": {"error_type": type(exc).__name__}}))
        return 1
    finally:
        if master is not None:
            master.dispose()
        if source is not None:
            source.dispose()
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
