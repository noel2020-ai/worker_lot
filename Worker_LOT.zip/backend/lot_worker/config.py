from pathlib import Path
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: SecretStr
    source_database_url: SecretStr
    source_schema: str = "dbo"
    # Fixed source mapping: override these dummy defaults in .env for production.
    source_table: str = "lot_demo_companies"
    source_id_column: str = "CompanyID"
    source_name_column: str = "CompanyName"
    source_address_column: str = "Address"
    source_city_column: str = "City"
    source_state_column: str = "State"
    source_province_column: str = "Province"
    master_database_url: SecretStr | None = None
    master_schema: str = "dbo"
    master_table: str = "lot_demo_accounts"
    master_account_id_column: str = "AccountID"
    master_address_column: str = "Address"
    master_city_column: str = "City"
    master_state_column: str = "State"
    master_province_column: str = "Province"
    master_max_rows: int = Field(default=250000, ge=1)
    address_similarity_min: float = Field(default=0.90, ge=0.80, le=1)
    account_score_min: int = Field(default=80, ge=0, le=100)
    output_root: Path = Path("output")
    input_root: Path = Path("data")
    input_file: str = "companies.xlsx"
    input_name_column: str = "CompanyName"
    input_sheet: str = "Sheet1"
    demo_company_file: str = "dummy_companies.csv"
    demo_master_file: str = "dummy_accounts.csv"
    match_mode: Literal["exact", "contains", "starts_with"] = "contains"
    daily_limit: int = Field(default=100, ge=1, le=100000)
    max_results: int = Field(default=100, ge=1, le=10000)
    timezone: str = "Asia/Manila"
    source_timeout_seconds: int = Field(default=60, ge=1, le=3600)

    @field_validator("source_schema", "source_table", "source_id_column",
                     "source_name_column", "source_address_column", "source_city_column",
                     "source_state_column", "source_province_column", "master_schema", "master_table",
                     "master_account_id_column", "master_address_column", "master_city_column",
                     "master_state_column", "master_province_column")
    @classmethod
    def valid_source_identifier(cls, value: str) -> str:
        if not value.strip() or len(value) > 128 or any(ord(char) < 32 for char in value):
            raise ValueError("Source identifiers must contain 1-128 characters without control characters")
        return value

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value: str) -> str:
        ZoneInfo(value)
        return value
