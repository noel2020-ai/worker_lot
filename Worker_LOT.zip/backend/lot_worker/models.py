from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, JSON, String, Unicode, UniqueConstraint, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class Job(Base):
    __tablename__ = "lot_search_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(Unicode(500))
    normalized_name: Mapped[str] = mapped_column(Unicode(500), unique=True)
    status: Mapped[str] = mapped_column(String(30), default="pending", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Attempt(Base):
    __tablename__ = "lot_search_attempts"
    __table_args__ = (UniqueConstraint("job_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("lot_search_jobs.id"), index=True)
    run_date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(30), default="running")
    match_mode: Mapped[str] = mapped_column(String(30))
    results: Mapped[list] = mapped_column(JSON, default=list)
    truncated: Mapped[bool] = mapped_column(default=False)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DemoBase(DeclarativeBase):
    pass


class DemoCompany(DemoBase):
    __tablename__ = "lot_demo_companies"
    CompanyID: Mapped[int] = mapped_column(primary_key=True, autoincrement=False)
    CompanyName: Mapped[str] = mapped_column(Unicode(500))
    Address: Mapped[str | None] = mapped_column(Unicode(1000), nullable=True)
    City: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)
    State: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)
    Province: Mapped[str | None] = mapped_column(Unicode(200), nullable=True)


class DemoAccount(DemoBase):
    __tablename__ = "lot_demo_accounts"
    RowID: Mapped[int] = mapped_column(primary_key=True, autoincrement=False)
    AccountID: Mapped[str] = mapped_column(Unicode(100))
    Address: Mapped[str] = mapped_column(Unicode(1000))
    City: Mapped[str] = mapped_column(Unicode(200))
    State: Mapped[str] = mapped_column(Unicode(200))
    Province: Mapped[str] = mapped_column(Unicode(200))
