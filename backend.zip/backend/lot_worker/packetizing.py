import json
import logging
import os

from .errors import error_details
from .packet_config import load_packet_configuration
from .packet_export import automatic_packet_export
from .packet_routing import route_account
from .source_records import selected_columns, source_mapping, source_records

logger = logging.getLogger(__name__)


def packetize(store, source, settings, records=None, mapping=None):
    try:
        configuration = load_packet_configuration(settings.packet_config_path)
    except Exception as exc:
        details = error_details(exc, "load_packet_configuration")
        return {"status": "error", "message": details["explanation"], "data": details}
    mapping = mapping or {"schema": settings.source_schema, "table": settings.source_table,
                          "columns": selected_columns(settings), "roles": source_mapping(settings)}
    with store.exclusive() as acquired:
        if not acquired:
            return {"status": "busy", "message": "Another local worker is running", "data": {}}
        store.recover()
        batch = store.create_batch(configuration.model_dump(), mapping)
        seen = set()
        try:
            stream = records if records is not None else source_records(source, settings)
            with (store.batch_path(batch["id"]) / "accounts.jsonl").open("x", encoding="utf-8") as output:
                for count, record in enumerate(stream, start=1):
                    if count > settings.source_max_rows:
                        raise ValueError("Source exceeds SOURCE_MAX_ROWS")
                    if not record["source_id"] or record["source_id"] in seen:
                        raise ValueError("Source IDs must be nonblank and unique")
                    seen.add(record["source_id"])
                    segregation = route_account(record["company_name"], configuration)
                    output.write(json.dumps({"sequence": count, "source": record, "segregation": segregation},
                                            ensure_ascii=False, allow_nan=False) + "\n")
                    batch["row_count"] = count
                    status = segregation["status"]
                    batch["routing"][status] = batch["routing"].get(status, 0) + 1
                    for packet_id in segregation["packet_ids"]:
                        batch["packet_counts"][packet_id] = batch["packet_counts"].get(packet_id, 0) + 1
                    if count % 500 == 0:
                        output.flush()
                        os.fsync(output.fileno())
                        store.save_batch(batch)
                        logger.info("packetization_progress batch_id=%s rows=%s", batch["id"], count)
                output.flush()
                os.fsync(output.fileno())
            batch["status"] = "ready"
            store.save_batch(batch)
        except Exception as exc:
            # Only the last committed snapshot is exposed after a failed write/read.
            batch = store.batches(batch["id"])[0]
            batch.update(status="failed", error_code=type(exc).__name__)
            store.save_batch(batch)
            return {"status": "error", "message": "Packetization failed; partial batch excluded from matching",
                    "data": {"batch_id": batch["id"], **error_details(exc, "packetize_source_or_local_save")}}
        finally:
            if "stream" in locals() and hasattr(stream, "close"):
                stream.close()
    logger.info("packetization_complete batch_id=%s rows=%s", batch["id"], batch["row_count"])
    return {"status": "success", "message": "Packets saved locally; ready for matching",
            "data": {"batch_id": batch["id"], "source_accounts": batch["row_count"],
                     "output_file": automatic_packet_export(store, settings.output_root, batch["id"])}}
