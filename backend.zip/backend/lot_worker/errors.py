"""Translate known driver codes without exposing raw SQL, parameters, or credentials."""
import re

from pydantic import ValidationError


SAFE_VALIDATOR_MESSAGES = {
    "Name patterns cannot be blank", "Packet name cannot be blank",
    "Specify rules for all four location fields", "Only address supports similarity matching",
    "Ignored fields require weight=0 and required=false", "Field weights must add up to 100",
    "At least one exact field must be required to bound masterfile candidates",
    "Packet IDs must be unique", "Packet names must be unique",
    "At least one packet must be enabled",
    "Source identifiers must contain 1-128 characters without control characters",
    "Additional source columns must be unique",
}


def validation_details(exc: ValidationError) -> list[dict]:
    from .config import Settings
    from .packet_config import (FieldRule, MatchingRules, NamePattern,
                                PacketConfiguration, PacketDefinition)

    names = {"address", "city", "state", "province"}
    for model in (Settings, FieldRule, MatchingRules, NamePattern, PacketConfiguration, PacketDefinition):
        names.update(model.model_fields)
    issues = []
    for error in exc.errors(include_url=False, include_input=False, include_context=False):
        location = [str(part) if isinstance(part, int) or part in names else "<unknown field>"
                    for part in error["loc"]]
        message = error["msg"].removeprefix("Value error, ")
        # Custom messages and unknown keys can contain user input; never echo them.
        if message not in SAFE_VALIDATOR_MESSAGES:
            message = {
                "missing": "Required field is missing",
                "extra_forbidden": "Remove this unrecognized field",
                "literal_error": "Use one of the allowed values defined in the configuration schema",
                "string_pattern_mismatch": "Packet ID must be a lowercase slug of 1-64 letters, digits, underscores or hyphens",
            }.get(error["type"], "Value does not satisfy the field type or constraint; check the configuration schema")
        issues.append({"field": ".".join(location) or "<root>",
                       "rule": error["type"], "message": message})
    return issues


DIAGNOSTICS = {
    207: ("invalid_column", "A configured database column does not exist.",
          "Compare SOURCE_COLUMNS_PATH and SOURCE_* / MASTER_* mappings with the columns in your existing tables. The worker never creates or changes columns."),
    208: ("missing_table", "A required table or view could not be resolved.",
          "Verify the existing source/master database, schema, table name, and SELECT access. No application tables are required."),
    229: ("permission_denied", "The database user lacks permission for this operation.",
          "Check SELECT permissions on the configured source/master tables or views. Write permissions are not required."),
    102: ("sql_syntax", "SQL Server rejected the statement syntax.",
          "Run check-db and report the failing command and stage, SQLSTATE, and native code."),
    156: ("sql_syntax", "SQL Server rejected the statement syntax.",
          "Run check-db and report the failing command and stage, SQLSTATE, and native code."),
    18456: ("login_failed", "SQL Server rejected the login.",
            "Check the configured authentication method and credentials without sharing connection strings."),
    4060: ("database_unavailable", "The configured database cannot be opened by this login.",
           "Check that the database exists and that the configured login has access."),
}


def error_details(exc: Exception, stage: str) -> dict:
    if isinstance(exc, ValidationError):
        return {"error_type": type(exc).__name__, "stage": stage, "sqlstate": None,
                "native_code": None, "category": "configuration_validation",
                "explanation": "Configuration validation failed.",
                "action": "Correct the fields listed in validation_errors. Packet fields are in PACKET_CONFIG_PATH; settings are in .env. List indexes start at zero.",
                "validation_errors": validation_details(exc)}
    original = getattr(exc, "orig", exc)
    arguments = getattr(original, "args", ())
    state = arguments[0] if arguments and isinstance(arguments[0], str) and re.fullmatch(r"[A-Z0-9]{5}", arguments[0]) else None
    # Inspect messages only for known numeric codes; never return the message itself.
    codes = [int(code) for argument in arguments if isinstance(argument, str)
             for code in re.findall(r"\((-?\d+)\)", argument)]
    native = next((code for code in codes if code in DIAGNOSTICS), None)
    fallback = {"42S22": 207, "42S02": 208}
    diagnosis = DIAGNOSTICS.get(native or fallback.get(state))
    if diagnosis is None:
        diagnosis = ("unclassified_error", "The command failed; the available error code does not identify the cause.",
                     "For database commands run check-db. For local operations check STATE_ROOT/OUTPUT_ROOT access and the configuration files; share the failing command and safe output.")
    category, explanation, action = diagnosis
    return {"error_type": type(exc).__name__, "stage": stage, "sqlstate": state,
            "native_code": native, "category": category, "explanation": explanation, "action": action}
