import logging
from collections import defaultdict

from sqlalchemy import Column, MetaData, String, Table, select

from .config import Settings
from .locations import compare_location, normalize_location, normalized_fields
from .matching import valid_address
from .packet_config import MatchingRules
from .packet_locations import compare_packet_location

logger = logging.getLogger(__name__)


def master_statement(settings: Settings):
    mapping = {"account_id": settings.master_account_id_column, "address": settings.master_address_column,
               "city": settings.master_city_column, "state": settings.master_state_column,
               "province": settings.master_province_column}
    table = Table(settings.master_table, MetaData(),
                  *(Column(column, String, quote=True) for column in dict.fromkeys(mapping.values())),
                  schema=settings.master_schema, quote=True, quote_schema=True)
    return select(*(table.c[column].label(alias) for alias, column in mapping.items()))


class MasterIndex:
    def __init__(self, records):
        self.by_city = defaultdict(list)
        self.indexes = {"city": self.by_city, **{field: defaultdict(list) for field in ("address", "state", "province")}}
        self.count = self.excluded = 0
        for record in records:
            self.count += 1
            if not record["account_id"]:
                raise ValueError("Masterfile has an empty account ID")
            if not valid_address(record["address"]):
                self.excluded += 1
                continue
            for field, value in normalized_fields(record).items():
                if value:
                    self.indexes[field][value].append(record)

    def candidates(self, source: dict, rules: MatchingRules | None):
        if rules is None:
            return self.by_city.get(normalize_location(source.get("city")), [])
        fields = normalized_fields(source)
        groups = [self.indexes[field].get(fields[field], []) for field, rule in rules.fields.items()
                  if rule.required and rule.mode == "exact"]
        return min(groups, key=len)

    def match(self, source: dict, settings: Settings, rules: MatchingRules | None = None) -> dict:
        accounts = {}
        for record in self.candidates(source, rules):
            evidence = compare_packet_location(source, record, rules) if rules is not None else compare_location(source, record, settings)
            if evidence is None:
                continue
            account = accounts.setdefault(record["account_id"], {
                "account_id": record["account_id"], "confidence_score": 0,
                "confidence_level": "low", "evidence": []})
            if evidence not in account["evidence"]:
                account["evidence"].append(evidence)
            if evidence["confidence_score"] > account["confidence_score"]:
                account.update(confidence_score=evidence["confidence_score"], confidence_level=evidence["confidence_level"])
        matches = sorted(accounts.values(), key=lambda row: (-row["confidence_score"], row["account_id"]))
        return {**source, "account_match_status": "matched" if matches else "no_match",
                "account_ids": [row["account_id"] for row in matches], "account_matches": matches,
                "multiple_accounts": len(matches) > 1,
                "review_required": len(matches) != 1 or any(row["confidence_level"] != "high" for row in matches),
                "no_match_reason": None if matches else "no_master_location_met_packet_rules" if rules is not None
                else "missing_city" if not normalize_location(source.get("city"))
                else "no_master_location_met_rules"}


def load_master_index(engine, settings: Settings) -> MasterIndex:
    def records():
        with engine.connect() as connection:
            result = connection.execution_options(stream_results=True).execute(master_statement(settings))
            try:
                for count, row in enumerate(result.mappings(), start=1):
                    if count > settings.master_max_rows:
                        raise ValueError("Masterfile exceeds MASTER_MAX_ROWS; no partial matching allowed")
                    yield {key: str(value).strip() if value is not None else "" for key, value in row.items()}
            finally:
                result.close()

    index = MasterIndex(records())
    logger.info("masterfile_loaded rows=%s excluded=%s", index.count, index.excluded)
    return index
