import unicodedata

from .packet_config import NamePattern, PacketConfiguration


def normalized_company(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


def matches_pattern(name: str, pattern: NamePattern) -> bool:
    value = normalized_company(pattern.value)
    if pattern.mode == "exact":
        return name == value
    if pattern.mode == "starts_with":
        return name.startswith(value)
    return value in name


def route_account(company_name: str, configuration: PacketConfiguration) -> dict:
    name = normalized_company(company_name)
    candidates = []
    for packet in sorted(configuration.packets, key=lambda item: (item.priority, item.id)):
        if not packet.enabled or any(matches_pattern(name, pattern) for pattern in packet.exclude):
            continue
        rules = [pattern.model_dump() for pattern in packet.include if matches_pattern(name, pattern)]
        if rules:
            candidates.append({"packet_id": packet.id, "packet_name": packet.name, "matched_rules": rules})
    selected = candidates
    status = "assigned" if candidates else "unassigned"
    if len(candidates) > 1:
        if configuration.overlap_policy == "review":
            selected, status = [], "ambiguous"
        elif configuration.overlap_policy == "priority":
            selected = candidates[:1]
    return {"status": status, "overlap_policy": configuration.overlap_policy,
            "candidate_packets": candidates, "packet_ids": [item["packet_id"] for item in selected]}
