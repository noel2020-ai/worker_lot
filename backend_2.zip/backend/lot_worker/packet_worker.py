import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from .errors import error_details
from .local_store import utc_now
from .masterfile import load_master_index
from .matching import valid_address
from .packet_config import PacketConfiguration
from .packet_export import automatic_packet_export

logger = logging.getLogger(__name__)


def local_day(settings):
    return datetime.now(ZoneInfo(settings.timezone)).date().isoformat()


def pending_tasks(store, batches):
    for batch in batches:
        if batch["status"] != "ready":
            continue
        tasks = store.progress(batch["id"])
        packets = {packet.id: packet for packet in PacketConfiguration.model_validate(batch["configuration"]).packets}
        for account in store.accounts(batch):
            for packet_id in account["segregation"]["packet_ids"]:
                key = f"{account['sequence']}-{packet_id}"
                if key not in tasks:
                    yield batch, tasks, key, account["source"], packets[packet_id]


def match_one(master, record, packet, settings):
    if not valid_address(record.get("address")):
        return "excluded_address", {"account_ids": [], "account_matches": [],
                                    "no_match_reason": "blank_or_po_box_address", "review_required": True}
    source = {key: value for key, value in record.items() if key != "source_data"}
    result = master.match(source, settings, rules=packet.matching)
    result["packet_id"] = packet.id
    result["master_source"] = {"schema": settings.master_schema, "table": settings.master_table,
                               "account_id_column": settings.master_account_id_column}
    return ("matched" if result["account_ids"] else "no_account_match"), result


def process_packets(store, source, settings, master_source=None, batch_id=None, master_index=None):
    attempts, errors = [], []
    with store.exclusive() as acquired:
        if not acquired:
            return {"status": "busy", "message": "Another local worker is running", "data": {}}
        store.recover()
        batches = store.batches(batch_id)
        if batch_id and batches[0]["status"] != "ready":
            raise ValueError("Requested batch is not ready")
        day = local_day(settings)
        used = store.daily_used(day)
        master = master_index
        for batch, tasks, key, record, packet in pending_tasks(store, batches):
            today = local_day(settings)
            if today != day:
                day, used = today, store.daily_used(today)
            if used >= settings.daily_limit:
                break
            if master is None:
                master = load_master_index(master_source if master_source is not None else source, settings)
            today = local_day(settings)
            if today != day:
                day, used = today, store.daily_used(today)
            if used >= settings.daily_limit:
                break
            # Persist the claim before work. A crash never refunds the charged attempt.
            tasks[key] = {"packet_id": packet.id, "status": "running", "run_date": day,
                          "started_at": utc_now(), "finished_at": None, "error_code": None, "has_result": False}
            store.save_progress(batch["id"], tasks)
            used += 1
            attempts.append(f"{batch['id']}:{key}")
            try:
                status, result = match_one(master, record, packet, settings)
                store.finish(batch["id"], key, tasks, status, result)
                logger.info("packet_match_complete batch_id=%s task=%s status=%s", batch["id"], key, status)
            except Exception as exc:
                errors.append(error_details(exc, "packet_matching_or_local_save"))
                store.finish(batch["id"], key, tasks, "failed", error_code=type(exc).__name__)
                break
    output = automatic_packet_export(store, settings.output_root, batch_id, attempts)
    return {"status": "error" if errors else "success", "message": "Packet matching run finished",
            "data": {"attempted": len(attempts), "failed": len(errors), "output_file": output,
                     **({"errors": errors} if errors else {})}}
