from difflib import SequenceMatcher

from .locations import address_identifiers, normalized_fields
from .matching import valid_address
from .packet_config import MatchingRules


def compare_packet_location(source: dict, master: dict, rules: MatchingRules) -> dict | None:
    if not valid_address(source.get("address")) or not valid_address(master.get("address")):
        return None
    left, right = normalized_fields(source), normalized_fields(master)
    matched, missing, ignored = [], [], []
    score, address_similarity = 0.0, None
    for field, rule in rules.fields.items():
        if rule.mode == "ignore":
            ignored.append(field)
            continue
        if not left[field] or not right[field]:
            if rule.required:
                return None
            missing.append(field)
            continue
        similarity = 1.0
        if left[field] == right[field]:
            matched.append(field)
        elif rule.mode == "exact":
            return None
        else:
            if address_identifiers(left[field]) != address_identifiers(right[field]):
                return None
            similarity = SequenceMatcher(None, left[field], right[field], autojunk=False).ratio()
            if similarity < rules.address_similarity_min:
                return None
        if field == "address":
            address_similarity = similarity
        score += rule.weight * similarity
    score = round(score)
    # A full location confidence requires all four fields, even for narrower packet rules.
    if ignored or address_similarity != 1.0:
        score = min(score, 94)
    if score < rules.minimum_score:
        return None
    return {"scoring_version": "packet-location-v1", "score_type": "rule_based_not_probability",
            "rules": rules.model_dump(), "confidence_score": score,
            "confidence_level": "high" if score == 100 and len(matched) == 4 else "medium" if score >= 85 else "low",
            "address_similarity": round(address_similarity, 4) if address_similarity is not None else None,
            "matched_fields": matched, "missing_fields": missing, "ignored_fields": ignored,
            "master_location": {field: master[field] for field in rules.fields}}
