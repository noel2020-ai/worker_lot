"""Exercise both layers with local CSV files; never connect to a database."""
from pathlib import Path

import pandas as pd

from .masterfile import MasterIndex
from .packetizing import packetize
from .packet_worker import process_packets


def read_demo_csv(root: Path, filename: str):
    root = root.resolve(strict=True)
    path = (root / filename).resolve(strict=True)
    if not path.is_relative_to(root) or not path.is_file() or path.suffix.lower() != ".csv":
        raise ValueError("Demo inputs must be CSV files within INPUT_ROOT")
    return pd.read_csv(path, dtype=str, keep_default_na=False).to_dict(orient="records")


def demo_records(settings):
    mapping = {"source_id": "CompanyID", "company_name": "CompanyName", "address": "Address",
               "city": "City", "state": "State", "province": "Province"}
    rows = read_demo_csv(settings.input_root, settings.demo_company_file)
    if not rows or not set(mapping.values()).issubset(rows[0]):
        raise ValueError("Demo CSV is missing required source columns")
    records = [{**{alias: row[column].strip() for alias, column in mapping.items()}, "source_data": row} for row in rows]
    return records, {"kind": "local_demo_csv", "columns": list(rows[0]), "roles": mapping}


def demo_master(settings):
    rows = read_demo_csv(settings.input_root, settings.demo_master_file)
    if len(rows) > settings.master_max_rows:
        raise ValueError("Demo master exceeds MASTER_MAX_ROWS")
    return MasterIndex({"account_id": row["AccountID"].strip(), **{field: row[field.title()].strip()
                       for field in ("address", "city", "state", "province")}} for row in rows)


def run_demo(store, settings):
    records, mapping = demo_records(settings)
    master = demo_master(settings)
    segregated = packetize(store, None, settings, records=iter(records), mapping=mapping)
    if segregated["status"] != "success":
        return segregated
    batch_id = segregated["data"]["batch_id"]
    result = process_packets(store, None, settings, batch_id=batch_id, master_index=master)
    result["data"]["batch_id"] = batch_id
    result["data"]["packet_snapshot"] = segregated["data"]["output_file"]
    return result
