import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def packet_export_payload(store, batch_id=None, task_ids=None):
    selected = set(task_ids) if task_ids is not None else None
    batches = []
    for batch in store.batches(batch_id):
        if selected is not None and not any(task.startswith(batch["id"] + ":") for task in selected):
            continue
        packets = {packet["id"]: {"packet_id": packet["id"], "packet_name": packet["name"],
                                  "matching_rules": packet["matching"], "account_ids": [], "accounts": []}
                   for packet in batch["configuration"]["packets"] if packet["enabled"]}
        tasks, review = store.progress(batch["id"]), []
        for account in store.accounts(batch):
            if account["segregation"]["status"] != "assigned" and selected is None:
                review.append({"source": account["source"], "segregation": account["segregation"]})
            for packet_id in account["segregation"]["packet_ids"]:
                key = f"{account['sequence']}-{packet_id}"
                task_id = f"{batch['id']}:{key}"
                if selected is not None and task_id not in selected:
                    continue
                task = tasks.get(key, {"status": "pending"})
                packets[packet_id]["accounts"].append({"task_id": task_id, "source": account["source"],
                    "segregation": account["segregation"], "status": task["status"], "run_date": task.get("run_date"),
                    "match_result": store.task_result(batch["id"], key, task), "error_code": task.get("error_code")})
        for packet in packets.values():
            packet["account_ids"] = sorted({account_id for account in packet["accounts"]
                for account_id in (account["match_result"] or {}).get("account_ids", [])})
        batches.append({"batch_id": batch["id"], "stage": batch["status"], "source_mapping": batch["source_mapping"],
                        "configuration": batch["configuration"], "source_account_count": batch["row_count"],
                        "packets": list(packets.values()), "unassigned_or_ambiguous": review,
                        "error_code": batch["error_code"]})
    return {"format_version": "packets-v1", "storage": "local_json",
            "export_scope": "attempted_tasks" if selected is not None else "batch_snapshot",
            "generated_at": datetime.now(timezone.utc).isoformat(), "batches": batches}


def export_packets(store, path: Path, batch_id=None, task_ids=None):
    payload = packet_export_payload(store, batch_id, task_ids)
    with path.open("x", encoding="utf-8") as output:
        json.dump(payload, output, indent=2, ensure_ascii=False, allow_nan=False)
    return {"output_file": str(path.resolve()), "batches": len(payload["batches"])}


def automatic_packet_export(store, output_root, batch_id=None, task_ids=None):
    output_root.mkdir(parents=True, exist_ok=True)
    prefix = "packets" if task_ids is None else "packet-matches"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return export_packets(store, output_root / f"{prefix}-{stamp}-{uuid4().hex}.json", batch_id, task_ids)["output_file"]
