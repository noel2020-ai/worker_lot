from pathlib import Path

import pandas as pd
import pytest
from sqlalchemy import Column, MetaData, String, Table, create_engine

from lot_worker.config import Settings
from lot_worker.database import enforce_readonly
from lot_worker.local_store import LocalStore

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def packet_environment(tmp_path):
    settings = Settings(_env_file=None, source_schema="main", master_schema="main",
                        source_table="lot_demo_companies", master_table="lot_demo_accounts",
                        input_root=ROOT / "examples", output_root=tmp_path / "output", state_root=tmp_path / "state",
                        packet_config_path=ROOT / "config/packets.json", source_columns_path=ROOT / "config/source_columns.json")
    # Only fixtures provision synthetic tables, before the read-only boundary is installed.
    engine = create_engine("sqlite://")
    for filename, name in [("dummy_companies.csv", "lot_demo_companies"), ("dummy_accounts.csv", "lot_demo_accounts")]:
        frame = pd.read_csv(ROOT / "examples" / filename, dtype=str, keep_default_na=False)
        table = Table(name, MetaData(), *(Column(column, String) for column in frame.columns))
        table.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(table.insert(), frame.to_dict(orient="records"))
    enforce_readonly(engine)
    yield engine, settings, LocalStore(settings.state_root)
    engine.dispose()
