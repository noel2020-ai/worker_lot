# Read-only SQL Server packet matching worker

The worker reads **existing source and masterfile tables with SELECT only**. It does not create databases or tables, insert/update/delete rows, or call SQL Server locking procedures. Packets, progress, daily limits, and results are saved in local JSON files. No application database or DBA-provisioned worker tables are required.

```mermaid
flowchart LR
    S[Existing source table: read only] --> P[Layer 1: packetize]
    P --> L[Local account snapshots and memberships]
    L --> M[Layer 2: packet-specific matching]
    A[Existing masterfile table: read only] --> M
    M --> J[Local progress, account IDs, confidence and JSON exports]
```

## Setup and configuration

Install Python 3.11+ and Microsoft ODBC Driver 18 for SQL Server. Run from the repository root:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e './backend[test]'
Copy-Item .env.example .env
```

For an existing setup, edit your `.env` instead of replacing it. `DATABASE_URL` is no longer used; old values are ignored. Configure your actual existing tables and use SELECT-only database credentials:

```dotenv
SOURCE_DATABASE_URL=mssql+pyodbc://reader:CHANGE_ME@localhost/company_data?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes&TrustServerCertificate=no
SOURCE_SCHEMA=dbo
SOURCE_TABLE=Companies
SOURCE_COLUMNS_PATH=./config/source_columns.json
SOURCE_ID_COLUMN=CompanyID
SOURCE_NAME_COLUMN=CompanyName
SOURCE_ADDRESS_COLUMN=Address
SOURCE_CITY_COLUMN=City
SOURCE_STATE_COLUMN=State
SOURCE_PROVINCE_COLUMN=Province
PACKET_CONFIG_PATH=./config/packets.json
MASTER_SCHEMA=dbo
MASTER_TABLE=AccountMaster
MASTER_ACCOUNT_ID_COLUMN=AccountID
MASTER_ADDRESS_COLUMN=Address
MASTER_CITY_COLUMN=City
MASTER_STATE_COLUMN=State
MASTER_PROVINCE_COLUMN=Province
STATE_ROOT=./state
OUTPUT_ROOT=./output
DAILY_LIMIT=100
TIMEZONE=Asia/Manila
SCHEDULE_TIME=09:00
```

If the masterfile is in a separate database, set `MASTER_DATABASE_URL` to its read-only SQL Server connection URL. Otherwise it uses `SOURCE_DATABASE_URL`. URL-encode password punctuation and keep `.env` out of source control. The complete template is [.env.example](.env.example).

| Editable file | Purpose |
| --- | --- |
| [config/source_columns.json](config/source_columns.json) | Initial list of 32 dummy columns; replace with your production column names |
| [config/packets.json](config/packets.json) | 14 editable packet definitions, aliases, exclusions, and matching rules |
| `.env` | Connections, tables, six field-role mappings, local folders, and daily limit |

The six mapped source columns must appear in the column list. Names are literal SQL identifiers, without brackets or SQL expressions. The source ID must identify a unique row. All selected columns are preserved in `source_data`; dates use ISO strings, decimals use strings to preserve precision, and binary values are tagged base64. The column list is configurable and is not limited to 32.

## Commands to run

```powershell
# Read-only check of your two existing tables and configured columns
.\.venv\Scripts\python.exe -m lot_worker.cli check-db

# Layer 1: read source accounts and save packets locally
.\.venv\Scripts\python.exe -m lot_worker.cli packetize

# Layer 2: match the saved accounts against the read-only masterfile
.\.venv\Scripts\python.exe -m lot_worker.cli run

# Local progress; no database connection needed
.\.venv\Scripts\python.exe -m lot_worker.cli status

# Local full export; no database connection needed
.\.venv\Scripts\python.exe -m lot_worker.cli export --output packet-results.json
```

Add `--batch-id YOUR_BATCH_ID` to `run`, `status`, or `export` to select a saved batch. The backend run command is `python -m lot_worker.cli run` inside the installed virtual environment. There is no frontend run command because this is a CLI worker.

**Do not run `init-db` or `seed-demo`: those commands have been removed.** Database-backed legacy commands have also been removed. The worker neither reads nor migrates the former `lot_*` application tables. Existing SQL Server objects are left untouched. A first local run starts a new local history and daily count; old SQL Server history is not imported.

`check-db` now checks only `source_columns` and `master_columns` using zero-row SELECT queries. It never checks for `lot_packet_batches`, `lot_search_jobs`, or other application tables. Error diagnostics include safe SQLSTATE/native codes and failing configured column names without exposing credentials or raw driver errors. If it reports a missing table, correct the source/master table, schema, database, or SELECT access. It does not provision anything.

## Layer 1: packet membership

The 14 editable examples are Amazon plus Cedar, Harbor, Maple, Summit, Willow, Quartz, Silver, Copper, Meadow, Pine, Birch, Aspen, and Oak. The other 13 names and all locations/account IDs are fictional placeholders.

Amazon has `contains` rules for `Amazon` and `AMZN`, capturing `123Amazon`, `AWSAmzn`, `ORD01AMZN`, and `TX-001Amzn`. Name rules support case-insensitive literal `contains`, `exact`, and `starts_with`; optional exclusion rules take precedence within their packet.

`overlap_policy: "all"` puts an account in every matching packet. Multiple aliases within the same packet create one membership. Unassigned accounts remain in the local snapshot and export. Blank/PO Box addresses also remain visible in packets, then are excluded in layer 2.

Every explicit `packetize` creates a new snapshot and new tasks. It scans the source once, saves progress every 500 rows, and becomes ready only after the complete read succeeds. Duplicate IDs, failed reads, or exceeding `SOURCE_MAX_ROWS` fail the batch; partial batches cannot enter matching. Changes to source rows or packet configuration do not change saved snapshots. Re-packetize only when a new snapshot is intended; this also creates new matching work for previously seen accounts.

## Layer 2: independent location rules

Each packet has its own rules for address, city, state, and province. Example:

```json
"matching": {
  "fields": {
    "address": {"mode": "similarity", "required": true, "weight": 70},
    "city": {"mode": "exact", "required": true, "weight": 10},
    "state": {"mode": "exact", "required": false, "weight": 10},
    "province": {"mode": "exact", "required": false, "weight": 10}
  },
  "address_similarity_min": 0.90,
  "minimum_score": 80
}
```

Weights total 100. All fields support normalized exact matching or ignoring; address also supports similarity. Ignored fields require zero weight and `required: false`. At least one exact field must be required to bound masterfile candidates. Required missing fields and conflicting active exact fields reject the match. Optional missing fields earn no points.

Blank/PO Box addresses are excluded regardless of packet rules. Address comparison normalizes common street/unit abbreviations and rejects differing numeric or explicit unit identifiers for approximate matches. It does not geocode or infer company ownership. Account IDs are strings, preserving leading zeros when the master stores them as text.

Scores are weighted, rule-based evidence, not calibrated probabilities. A high score of 100 requires agreement on all four fields. Ignored fields or approximate addresses cap the score at 94; scores from 85 are medium, and lower accepted scores are low. Every qualifying master account ID is retained, with duplicate rows grouped under that ID and supporting evidence preserved. Multiple IDs and non-high matches require review.

The masterfile is read once per active run and bounded by `MASTER_MAX_ROWS`; exceeding the limit fails before charging new attempts. Matching reads source accounts from local snapshots, not from the live source table. Results automatically export under `OUTPUT_ROOT` grouped by packet and batch.

## Local persistence, progress and daily limits

```text
state/
  worker.lock
  batches/<batch-id>/
    batch.json          # Saved packet configuration, source mapping and counts
    accounts.jsonl      # Source snapshots and packet memberships
    progress.json       # Durable claims, daily charges and statuses
    results/*.json      # Per-account/packet matching results
output/
  packets-*.json
  packet-matches-*.json
```

Folders are created automatically. An operating-system file lock prevents overlapping writers using the same `STATE_ROOT`. JSON state updates use temporary files, flushing, and atomic replacement. Claims are saved before matching, so restarts do not refund the daily allowance. Interrupted work is marked on the next run without automatic retry. Missing/corrupt progress fails instead of silently resetting it.

`DAILY_LIMIT=100` means 100 account/packet attempts per local calendar day. An account in two packets consumes two attempts. Exclusions and failures count. Completed tasks do not repeat on a later run. Keep all production invocations on the same local `STATE_ROOT` and timezone; separate state folders have separate limits. Back up that directory and do not remove/edit progress to resume work. Local history is the source of the daily count. Distributed coordination across separate machines or network shares is not implemented.

`status` shows per-packet counts, completion percentages, and today's used/remaining allowance. Completed includes unsuccessful/excluded tasks; it does not mean all were matched. Status and export work without SQL credentials. Exports refuse to overwrite an existing file. If export fails, saved results can be exported later without repeating matching. For very large retained histories, progress-file loading and JSON exports may need additional storage/indexing work.

## Local dummy demo

```powershell
.\.venv\Scripts\python.exe -m lot_worker.cli demo
```

This command reads the included dummy CSVs and runs both layers without connecting to SQL Server. It uses `STATE_ROOT/demo` and `OUTPUT_ROOT/demo`, separate from production work and its quota. The initial dataset has 23 source accounts with 32 columns, 14 packets, and 13 masterfile rows. It creates 23 matching tasks from 22 assigned source rows (one account belongs to two packets); one source row is unassigned. `INPUT_ROOT`, `DEMO_COMPANY_FILE`, and `DEMO_MASTER_FILE` configure these CSV paths. Paths escaping `INPUT_ROOT` are rejected.

See [examples/packet_matching_sample.json](examples/packet_matching_sample.json) for a generated local-only export. Repeating `demo` creates another demo snapshot and uses the demo daily allowance.

## Scheduling and tests

```powershell
.\scripts\register-daily-task.ps1
Get-ScheduledTask -TaskName CompanySearchWorker
.\.venv\Scripts\python.exe -m pytest backend/tests -q
```

The scheduled action runs layer 2 against ready local packets. Run `packetize` explicitly when a new snapshot is needed. It uses the same working directory, virtual environment, `.env`, and local state. The script schedules in Windows local time; align it with `TIMEZONE`. By default it runs while the user is logged in. Configure an appropriate Task Scheduler account for logged-out execution and ensure that account can read/write the same local state/output folders. Console logs are not persisted by the scheduling script.

Tests verify read-only SQL guards, the two existing-table diagnostics, local persistence, packet overlap, all 32 columns, daily limits, process locking, crash recovery, and matching evidence. SQL fixtures use temporary SQLite tables prepared by tests only; the application has no schema creation or SQL write path. Production SQL Server connectivity and scheduled execution remain unverified.

No Google Search API or Hoovers/D&B integration is included. Production table/column mappings and packet rules must be supplied in configuration.
