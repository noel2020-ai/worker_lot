import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError

from lot_worker.local_store import LocalStore
from lot_worker.packet_config import MatchingRules, PacketConfiguration, load_packet_configuration
from lot_worker.packet_export import packet_export_payload
from lot_worker.packet_locations import compare_packet_location
from lot_worker.packet_progress import packet_progress
from lot_worker.packet_routing import route_account
from lot_worker.packet_worker import process_packets
from lot_worker.packetizing import packetize
from lot_worker.source_records import json_value, selected_columns

ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.parametrize("name", ["123Amazon", "AWSAmzn", "ORD01AMZN", "TX-001Amzn"])
def test_requested_aliases(name):
    config = load_packet_configuration(ROOT / "config/packets.json")
    assert route_account(name, config)["packet_ids"] == ["amazon"]
    assert len(config.packets) == 14


def test_overlapping_membership_and_exclusions():
    config = load_packet_configuration(ROOT / "config/packets.json")
    assert route_account("Amazon Cedar Shared", config)["packet_ids"] == ["amazon", "cedar"]
    changed = config.model_dump()
    changed["packets"][0]["exclude"] = [{"mode": "contains", "value": "Shared"}]
    assert route_account("Amazon Cedar Shared", PacketConfiguration.model_validate(changed))["packet_ids"] == ["cedar"]


def test_independent_packet_rules():
    source = {"address": "100 Example Street", "city": "City A", "state": "State", "province": "Province"}
    master = {**source, "city": "City B"}
    strict = MatchingRules()
    assert compare_packet_location(source, master, strict) is None
    alternate = strict.model_dump()
    alternate["fields"]["city"] = {"mode": "ignore", "required": False, "weight": 0}
    alternate["fields"]["province"] = {"mode": "exact", "required": True, "weight": 20}
    evidence = compare_packet_location(source, master, MatchingRules.model_validate(alternate))
    assert evidence["confidence_score"] == 94 and evidence["ignored_fields"] == ["city"]


def test_local_two_layers_all_columns_overlap_quota_restart_and_export(packet_environment):
    engine, settings, store = packet_environment
    result = packetize(store, engine, settings)
    assert result["status"] == "success"
    batch_id = result["data"]["batch_id"]
    snapshot = packet_export_payload(store, batch_id)["batches"][0]
    assert snapshot["source_account_count"] == 23 and len(snapshot["packets"]) == 14
    amazon = next(packet for packet in snapshot["packets"] if packet["packet_id"] == "amazon")
    assert len(amazon["accounts"]) == 6
    assert all(len(account["source"]["source_data"]) == 32 for account in amazon["accounts"])
    assert all(account["status"] == "pending" for account in amazon["accounts"])
    assert len(snapshot["unassigned_or_ambiguous"]) == 1
    assert packet_progress(store, settings)["attempted_today"] == 0
    source_unavailable = MagicMock()
    source_unavailable.connect.side_effect = AssertionError("Layer 2 must not re-read source accounts")
    settings.daily_limit = 2
    assert process_packets(store, source_unavailable, settings, master_source=engine)["data"]["attempted"] == 2
    restarted = LocalStore(settings.state_root)
    assert process_packets(restarted, source_unavailable, settings, master_source=engine)["data"]["attempted"] == 0
    assert packet_progress(restarted, settings)["remaining_today"] == 0
    settings.daily_limit = 100
    assert process_packets(restarted, source_unavailable, settings, master_source=engine)["data"]["attempted"] == 21
    exported = packet_export_payload(restarted, batch_id)
    assert exported["storage"] == "local_json"
    amazon = next(packet for packet in exported["batches"][0]["packets"] if packet["packet_id"] == "amazon")
    assert amazon["account_ids"] == ["000101", "000102"]
    assert packet_progress(restarted, settings, batch_id)["batches"][0]["packets"]["amazon"]["progress_percent"] == 100
    assert process_packets(restarted, None, settings)["data"]["attempted"] == 0
    assert sum(task["status"] == "excluded_address" for task in store.progress(batch_id).values()) == 6


def test_failed_partial_snapshot_cannot_match(packet_environment):
    engine, settings, store = packet_environment
    settings.source_max_rows = 2
    result = packetize(store, engine, settings)
    assert result["status"] == "error"
    assert store.batches(result["data"]["batch_id"])[0]["status"] == "failed"
    assert process_packets(store, None, settings)["data"]["attempted"] == 0


def test_duplicate_ids_fail_snapshot(packet_environment):
    _, settings, store = packet_environment
    record = {"source_id": "1", "company_name": "Amazon", "address": "1 Test Street",
              "city": "Test", "state": "", "province": "", "source_data": {}}
    assert packetize(store, None, settings, records=iter([record, record]))["status"] == "error"
    assert store.batches()[0]["status"] == "failed"


def test_column_list_requires_all_mappings(packet_environment, tmp_path):
    _, settings, _ = packet_environment
    assert len(selected_columns(settings)) == 32
    path = tmp_path / "columns.json"
    path.write_text('["CompanyID", "CompanyName"]', encoding="utf-8")
    settings.source_columns_path = path
    with pytest.raises(ValueError, match="six mapped"):
        selected_columns(settings)


def test_source_types_preserve_precision():
    data = {"Revenue": json_value(Decimal("1234567890.123456789")), "Date": json_value(date(2026, 9, 22)),
            "Null": json_value(None), "Binary": json_value(b"\x00\x01")}
    assert json.loads(json.dumps(data)) == {"Revenue": "1234567890.123456789", "Date": "2026-09-22",
                                          "Null": None, "Binary": {"encoding": "base64", "value": "AAE="}}


def test_invalid_weights_rejected():
    config = MatchingRules().model_dump()
    config["fields"]["city"]["weight"] = 100
    with pytest.raises(ValidationError):
        MatchingRules.model_validate(config)
